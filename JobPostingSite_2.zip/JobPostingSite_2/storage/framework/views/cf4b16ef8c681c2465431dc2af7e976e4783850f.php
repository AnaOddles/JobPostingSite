 

<?php $__env->startSection('content'); ?>

<div class="container">
	<h1>Job Postings</h1>

	<!-- start of the table -->

	<div class="container" padding="50px">

		<table class="table table-hover">

			<thead>

				<tr>

					<!-- table header data -->
					<th scope="col">ID</th>

					<th scope="col">Title</th>
					
					<th scope="col">Location</th>

					<th scope="col">Salary</th>
					
					<th scope="col">Description</th>
					
					<th scope="col">Type</th>

				</tr>

			</thead>

			<tbody>
				<!-- populate the table with the appropriate user information -->
				<?php
				foreach ($jobs as $job) {
    				echo "<tr>";

    				echo "<th scope='row'>" . $job->id . "</th>";
    				echo "<td>" . $job->title . "</td>";
    				echo "<td>" . $job->location . "</td>";
    				echo "<td>" . $job->salary . "</td>";
    				echo "<td>" . $job->description . "</td>";
    				echo "<td>" . $job->type . "</td>";
    
    				echo "</tr>";
				}
				?>

			
			</tbody>

		</table>

	</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasanchez/CST-256/JobPostingSite/resources/views/jobposting/index.blade.php ENDPATH**/ ?>