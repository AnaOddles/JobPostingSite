<img src="{{ $message->embed(public_path().'/images/noCopyrightJobImage.jpg') }}">

<br>

<strong>{{ $name }}, welcome to the Job Posting Site!</strong>

  <p>
  {{ $body }}
  </p>

  <p>
  Take the first step and start building your profile now! Access the site at https://jobpostingsite.azurewebsites.net/myapp/public to get started.
  </p>
  
  <p>
  Sincerely, <br>
  The Job Posting Site Team <br>
  Ana Sanchez and Kacey Morris
  </p>