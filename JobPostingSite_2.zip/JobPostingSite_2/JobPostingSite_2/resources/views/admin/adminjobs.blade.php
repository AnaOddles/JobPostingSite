@extends('layouts.app') 

@section('content')

<div class="container">
	<h1>Admin Job Postings</h1>
	<a href="{{route('createJobadmin')}}">Add Job</a>

	<!-- start of the table -->

	<div class="container" padding="50px">

		<table class="table table-hover">

			<thead>

				<tr>

					<!-- table header data -->
					<th scope="col">ID</th>

					<th scope="col">Title</th>
					
					<th scope="col">Location</th>

					<th scope="col">Salary</th>
					
					<th scope="col">Description</th>
					
					<th scope="col">Type</th>
					
					<th scope="col">Edit</th>
					
					<th scope="col">Delete</th>

				</tr>

			</thead>

			<tbody>
				<!-- populate the table with the appropriate user information -->
				<?php
				foreach ($jobs as $job) {
    				echo "<tr>";

    				echo "<th scope='row'>" . $job->id . "</th>";
    				echo "<td>" . $job->title . "</td>";
    				echo "<td>" . $job->location . "</td>";
    				echo "<td>" . $job->salary . "</td>";
    				echo "<td>" . $job->description . "</td>";
    				echo "<td>" . $job->type . "</td>";
    				
    				
    				// form to edit a job posting
    				
    				echo "<td>";
    				?>
    	
 					<form action="{{route('editjobadmin', ['job' => $job->id]) }}" method='post'>
 						@csrf
     				<?php
    				echo "<form action='{{ route('editJob') }}'>";
    				echo "<input type='hidden' name='id' value='" . $job->id . "'>";
    				echo "<input class='btn btn-info' type='submit' name='submit' value='+'>";
    				echo "</form>";
    				echo "</td>";
    				
    				
    				// form to delete a job posting
    				
    				echo "<td>";
    				?>
    	
 					<form action="{{route('deleteJobadmin', ['job' => $job->id]) }}" method='post'>
 						@csrf
   						@method("PATCH")
     				<?php
    				echo "<form action='{{ route('deleteJob') }}'>";
    				echo "<input type='hidden' name='id' value='" . $job->id . "'>";
    				echo "<input class='btn btn-danger' type='submit' name='submit' value='x'>";
    				echo "</form>";
    				echo "</td>";
    
    				echo "</tr>";
				}
				?>

			
			</tbody>

		</table>

	</div>

</div>
@endsection
