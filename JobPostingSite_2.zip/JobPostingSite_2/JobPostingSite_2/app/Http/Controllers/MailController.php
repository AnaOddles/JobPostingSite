<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class MailController extends Controller
{
	// no arguments
	// this is sending email with html format
	public function basic_email($name, $email) {
		// get from registration
		$to_name = $name;
		$to_email = $email;
		
		// welcome message for the user
		$to_subject = "Job Posting Site Welcome";
		// From part of the email
		$from_name = "Job Posting Site Team - Runtime Terror";
		$from_email = "jobpostingsite.256@gmail.com";
		
		// define the array for the information to be included in the email\
		// get the name from the registration
		$data = array('name'=>$name, 'body'=>'Thank you for signing up for the Job Posting Site! 
						By joining, you have taken the first step in finding the job that is right for you. 
						On this site, you will be able to create a profile and tell us a little about yourself, 
						but also create a portfolio to display your skills to potential future employers! 
						You will also be able to view all available jobs, or search for a specific type of job, 
						and apply right through the website! Join groups and get connected to start your future. 
						What are you waiting for! Get started now.');
		
		// use the mail class to send the email out
		// mail is the view we are using
		// $data is the array defining the body
		// you can pass the necessary variables with the use keyword
		// view first, data, 
		// for different directory in views, do email.mail (email is dir name)
		// Photo by Andy Vu from Pexels (NO COPYRIGHT)
		// in mail.blade.php, in azure, may need to change public_path to base_path
		Mail::send('email.mail', $data, function($message) 
				use($to_name, $to_email, $to_subject, $from_email, $from_name) {
					$message->to($to_email, $to_name)->subject($to_subject);
					$message->from($from_email, $from_name);
				}
		);
		// echo email sent message
		echo "Basic Email Sent. Check your inbox.";
	}
}
