<?php
namespace App\Models\Api;


class JobPostingDTO implements \JsonSerializable
{
    //DTO properties
    public $errorCode;
    public $errorMessage;
    public $data;
    
    //DTO contrcutor
    public function __construct($data, $optionalParam)
    {
        //FOR GRABBING ONE JOB VIA ID 
        
        //If an id was passed
        if($optionalParam != null){  
            //If the id that was passed was not numeric
            if(! is_numeric($optionalParam)){
                $this->errorCode = "5051";
                $this->errorMessage = "Non numeric id";
                $this->data = "none";
            }
            //If no jobs were found with provided id - returned empty json for data
            elseif($data == '[]'){
                $this->errorCode = "5052";
                $this->errorMessage = "Posting not found with such id";
                $this->data = "none";
            }
            //Else sucessfully pulled jobs
            else{
               
                    $this->errorCode = "200";
                    $this->errorMessage = "No error - job posting pulled";
                    $this->data = $data;
                
            }
            
                
        }
       //FOR GRABBING ALL JOBS
       
        //if no Id was passed to DTO
        else {
            $this->data = $data;
            
            //Grab the count of jobs
            $jobs_array = json_decode($data);
            $jobs = array();
            $count = 0;
            
            //If there are more than 20 jobs
            if(count($jobs_array) > 20)
            {
                //trim the array of jobs to 20
                foreach ($jobs_array as $job)
                {
                    $count++;
                    if($count <= 20)
                    {
                        $jobs[] = $job;
                    }
                     
                }
                
                $this->errorCode = "5054";
                $this->errorMessage = "Limit exceeded - can only pull 20 jobs";
                //Still return the first twenty jobs - trimmed
                $this->data = $jobs;
            }
            //Else if no job postings were found
            else 
            {
            //If no jobs were found - returned empty json for data
            
            if($data == '[]')
            {
                $this->errorCode = "5050";
                $this->errorMessage = "No job postings found";
            }
            
            //Else successfully pulled jobs - only if there are 
            //20 or less jobs
            else
            {
                $this->errorCode = "200";
                $this->errorMessage = "No error - job postings pulled";
            }
        }
        }
        
        
    }
    
    //JsonSeralize interface method that returns obj as json format
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
    
}

