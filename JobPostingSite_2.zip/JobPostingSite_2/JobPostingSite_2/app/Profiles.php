<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Profiles extends Model implements \JsonSerializable
{
    protected $guarded = [];
      
    //One to one relationship with profile
    
    //Profile also contains a user model
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    
    public function profileImage()
    {
        $imagePath = ($this->image) ? $this->image : 'profile/3XzW6JOhj4MoQn4KScDxnV04PaEr7HIXMRegtUVW.png';
        return '/storage/' . $imagePath;
    }
    
    //JsonSeralize interface method that returns obj as json format
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }
}
