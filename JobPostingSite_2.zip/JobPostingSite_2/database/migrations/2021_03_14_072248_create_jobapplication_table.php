<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobapplicationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jobapplication', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('jobposting_id');
            $table->string('first_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('email')->nullable();
            //$table->boolean('18_or_above')->nullable();
            //$table->boolean('require_sponsorship')->nullable();
            //$table->boolean('background_check_consent')->nullable();
            //$table->boolean('convicted_of_crime')->nullable();
            //$table->string('start_date')->nullable();
            
            
            //Index on foreign key - for user table
            $table->index('user_id');
            $table->index('jobposting_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jobapplication');
    }
}
