<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateProfilesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('profiles', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('user_id');
            $table->string('image')->nullable();
            $table->string('headline')->nullable();
            $table->string('location')->nullable();
            //$table->text('education')->nullable;
            $table->text('about')->nullable();
            //$table->text('licenseAndCertifications')->nullable;
            //$table->text('skills')->nullable;
            //$table->text('experience')->nullable;
            $table->timestamps();
            
            
            //Index on foreign key - for user table
            $table->index('user_id');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('profiles');
    }
    
    
}
