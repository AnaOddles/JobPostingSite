@extends('layouts.app') 
@section('content')
@foreach($jobPostings as $job)
<div class="container">
	<form action="{{route('applyJob_2' , ['jobTitle' => $job->title])}}" enctype="multipart/form-data" method="post">
		@csrf
		<div class="row">
			<div class="col-8 offset-2">
			<div class="row">
					<h3><?php echo $job->title?> - <?php echo $job->company?></h3>
				</div>
				<div class="row pt-4">
					<h5>General Information</h5>
				</div>
				<input type="hidden" name='jobApplicationID' value="<?php echo $jobApplicationId ?>">
				
				<div class="form-group row">
					<label for="firstName" class="col-md-4 col-form-label">First Name:</label>
					

					<input id="firstName" type="text"
						class="form-control"
						name="firstName" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="lastName" class="col-md-4 col-form-label">Last Name:</label>
					

					<input id="lastName" type="text"
						class="form-control"
						name="lastName" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="email" class="col-md-4 col-form-label">Email:</label>


					<input id="email" type="text"
						class="form-control"
						name="email" 
						value="<?php echo auth()->user()->email?>" required> 
				</div>
				
				<div class="row pt-4">
					<h5>Contact Infromation</h5>
				</div>
				
				<div class="form-group row">
					<label for="address" class="col-md-4 col-form-label">Address:</label>


					<input id="address" type="text"
						class="form-control"
						name="address" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="city" class="col-md-4 col-form-label">City:</label>


					<input id="city" type="text"
						class="form-control"
						name="city" 
						value="" required> 
				</div>
				
				
				<div class="form-group row">
					<label for="state" class="col-md-4 col-form-label">State:</label>


					<input id="state" type="text"
						class="form-control"
						name="state" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="country" class="col-md-4 col-form-label">Country:</label>


					<input id="country" type="text"
						class="form-control"
						name="country" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="zipCode" class="col-md-4 col-form-label">ZipCode:</label>


					<input id="zipCode" type="text"
						class="form-control"
						name="zipCode" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="phone" class="col-md-4 col-form-label">Phone:</label>


					<input id="phone" type="text"
						class="form-control"
						name="phone" 
						value="" required> 
				</div>	
				
				<div class="row pt-4">
					<h5>Qualifications</h5>
				</div>
				<input type='hidden' name='jobApplicationID' value="<?php echo $jobApplicationId ?>">
				
				<div class="form-group row">
					<label for="education" class="col-md-4 col-form-label">Education:</label>
					

					<input id="education" type="text"
						class="form-control"
						name="education" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="licenseAndCertifications" class="col-md-4 col-form-label">License and Certifications:</label>
					

					<input id="licenseAndCertifications" type="text"
						class="form-control"
						name="licenseAndCertifications" 
						value="">
						
				</div>
				
				<div class="form-group row">
					<label for="skills" class="col-md-4 col-form-label">Skills:</label>


					<input id="skills" type="text"
						class="form-control"
						name="skills" 
						value="" required> 
				</div>
				
				<div class="form-group row">
					<label for="experience" class="col-md-4 col-form-label">Experience:</label>


					<input id="experience" type="text"
						class="form-control"
						name="experience" 
						value="" required> 
				</div>		
					
				
				
				<div class="row pt-4">
					<button class="btn btn-primary">Submit</button>
				</div>
				
			</div>
			
			
			</div>
			
			
			
			</form>
			
		</div>
	
	@endforeach
@endsection

