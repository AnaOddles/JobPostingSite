@extends('layouts.app') @section('content')

<div class="container">
	<h1>Admin Users</h1>
	<a href="{{route('createJobadmin')}}">Add Job</a>	<br/>
	<a href="{{route('admin.jobs')}}">Manage Jobs</a>

	<!-- start of the table -->

	<div class="container" padding="50px">

		<table class="table table-hover">

			<thead>

				<tr>

					<!-- table header data -->
					<th scope="col">ID</th>

					<th scope="col">Name</th>

					<th scope="col">Email</th>

					<th scope="col">Type</th>

					<th scope="col">Suspended?</th>

					<th scope="col">Suspend</th>

					<th scope="col">Delete</th>

				</tr>

			</thead>

			<tbody>
				<!-- populate the table with the appropriate user information -->
<?php
foreach ($users as $user) {
    echo "<tr>";

    echo "<th scope='row'>" . $user->id . "</th>";
    echo "<td>" . $user->name . "</td>";
    echo "<td>" . $user->email . "</td>";

    // to change role, mini form
    echo "<td>";

    ?>
    <form action="{{route('user.roleUpdate', ['user' => $user->id]) }}" method='post'>
   
    @csrf
    @method("PATCH")
    
    <?php
    echo "<input type='hidden' name='id' value='" . $user->id . "'>";

    echo "<div class='form-check'>";
    echo "<input class='form-check-input' type='radio' name='radio' id='defaultRadio' value='default'";

    // checking for which radio button to have checked
    if ($user->type == 'default') {
        echo " checked>";
    } else {
        echo ">";
    }

    echo "<label class='form-check-label' for='defaultRadio'>default</label>";
    echo "</div>";

    echo "<div class='form-check'>";
    echo "<input class='form-check-input' type='radio' name='radio' id='adminRadio' value='admin'";
    // checking if admin radio should be checked
    if ($user->type == 'admin') {
        echo " checked>";
    } else {
        echo ">";
    }

    echo "<label class='form-check-label' for='adminRadio'>admin</label>";
    echo "</div>";

    echo "<input class='btn btn-secondary' type='submit' name='submit' value='Update'>";
    // echo "</span>";
    echo "</form>";
    echo "</td>";
    
    $suspended = 'NO';
    if($user->suspended)
        $suspended = 'YES';
    
    echo "<td>" . $suspended . "</td>";

    // form to suspend a user
    echo "<td>";

    ?> 
    
 		<form action="{{route('user.suspendUser', ['user' => $user->id]) }}" method='post'>
 		@csrf
    	@method("PATCH")
     <?php

    echo "<input type='hidden' name='id' value='" . $user->id . "'>";
    echo "<input class='btn btn-warning' type='submit' name='submit' value='-'>";
    echo "</form>";
    echo "</td>";

    // form to delete a user completely

    echo "<td>";
    ?>
    	
 		<form action="{{route('user.deleteUser', ['user' => $user->id]) }}" method='post'>
 		@csrf
   		@method("PATCH")
     <?php
    echo "<form action='{{ route('deleteUser') }}'>";
    echo "<input type='hidden' name='id' value='" . $user->id . "'>";
    echo "<input class='btn btn-danger' type='submit' name='submit' value='x'>";
    echo "</form>";
    echo "</td>";

    echo "</tr>";
}
?>

			
			</tbody>

		</table>

	</div>

</div>

@endsection
