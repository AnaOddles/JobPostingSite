@extends('layouts.app') @section('content')
<div class="container">
	<!--<form action="{{route('storeJobAdmin')}}" enctype="multipart/form-data" method="post">
		@csrf   -->
		<div class="row">
			<div class="col-8 offset-2">
				<div class="row">
					<h1>Add New Job</h1>
				</div>
				<a href="/admin/jobs">Back</a>
				<div class="form-group row">
					<label for="title" class="col-md-4 col-form-label">Title:</label>


					<input id="title" type="text"
						class="form-control"
						name="title"> 
				</div>
				
				<div class="form-group row">
					<label for="company" class="col-md-4 col-form-label">Company:</label>


					<input id="company" type="text"
						class="form-control"
						name="company"> 
				</div>
				
				
				<div class="form-group row">
					<label for="type" class="col-md-4 col-form-label">Type:</label>


					<input id="type" type="text"
						class="form-control"
						name="type"> 
				</div>
				
				<div class="form-group row">
					<label for="location" class="col-md-4 col-form-label">Location:</label>


					<input id="location" type="text"
						class="form-control"
						name="location"> 
				</div>
				
				<div class="form-group row">
					<label for="salary" class="col-md-4 col-form-label">Salary:</label>


					<input id="salary" type="text"
						class="form-control"
						name="salary"> 
				</div>
				
				<div class="form-group row">
					<label for="description" class="col-md-4 col-form-label">Description:</label>


					<input id="description" type="text"
						class="form-control"
						name="description"> 
				</div>
				
				<div class="form-group row">
					<label for="qualifications" class="col-md-4 col-form-label">Qualifications:</label>


					<input id="qualifiations" type="text"
						class="form-control"
						name="qualifications"> 
				</div>
				
<!-- 				<div class="form-group row"> -->
<!-- 					<label for="postedOn" class="col-md-4 col-form-label">Posted Date:</label> -->


<!-- 					<input id="postedOn" type="text" -->
<!-- 						class="form-control" -->
<!-- 						name="postedOn">  -->
<!-- 				</div> -->

				<div class="row pt-4">
					<button class="btn btn-primary">Add New Job</button>
				</div>

			</div>
		</div>
<!-- 	</form> -->
</div>
@endsection
