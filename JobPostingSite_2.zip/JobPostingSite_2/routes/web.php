<?php
/*
 * Name: Mann Jaiswal, Kacey Morris, Ana Sanchez
 * Php 3 Laravel
 * All work is our as influenced  by in class lecture
 */
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Routes the user to the home page
Route::get('/', function () {
    return view('welcome');
});


//AUTH ROUTES

//Routes the user for authorization on login and register
Auth::routes();


//GET route for logging out
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');

//home page route
Route::get('/home', 'HomeController@index')->name('home');


//PROFILE ROUTES 


//GET Route to view the user profile
Route::get('/profiles/{user}', 'ProfilesController@index')->name('profile.show');

//GET route to edit profile
Route::get('/profile/{user}/edit', 'ProfilesController@edit')->name('profile.edit');

//PATCH route to update the user profile
Route::patch('/profile/{user}', 'ProfilesController@update')->name('profile.update');

//ADMIN ROUTES 

//GET route for the admin page
Route::get('/admin', 'AdminController@admin')
//uses the middleware for admin
->middleware('is_admin')
->name('admin');





//ADMIN ROUTES
Route::patch('admin/{user}/updateRole' ,'AdminController@updateRole')->name('user.roleUpdate');

Route::patch('admin/{user}/suspendUser','AdminController@suspendUser')->name('user.suspendUser'); 

Route::patch('admin/{user}/deleteUser','AdminController@deleteUser')->name('user.deleteUser');

//JOB POSTING ROUTES\

//Admin job posting routes
Route::get('jobposting/create', 'JobPostingsController@create')->name('createJob')
->middleware('is_admin')
->name('admin');

//Route for Admin to see jobs
Route::get('admin/jobs', 'AdminController@showAdmin')
->middleware('is_admin')
->name('admin.jobs');
//uses the middleware for admin



Route::post('admin/{jobID}/editJob', "AdminController@editJob")->name('editjob')
//uses the middleware for admin
->middleware('is_admin')
->name('admin');

Route::patch('admin/{jobID}/updateJob', "AdminController@updateJob")->name('updatejob');

Route::patch('admin/{jobID}/deleteJob', "AdminController@deleteJob")->name('deleteJob')
->middleware('is_admin')
->name('admin');

//Route to see all jobs
Route::get('jobs', 'JobPostingsController@show')->name('jobposting.show')
->middleware('auth');

//POST route to actaully store the jobs into the database
Route::post('/addjobposting', 'JobPostingsController@store')
->middleware('is_admin')
->name('storeJobAdmin');




//PORTFOLIO ROUTES

//GET Route to view the user profile
Route::get('/portfolios/{user}', 'PortfoliosController@index')->name('portfolio.show')
->middleware('auth');
//GET route to edit profile
Route::get('/portfolio/{user}/edit', 'PortfoliosController@edit')->name('portfolio.edit');
//PATCH route top update the user portfolio
Route::patch('/portfolio/{user}', 'PortfoliosController@update')->name('portfolio.update');

Route::any('any', function()
{
    return "Anything is possiblr if you try hard!";
});








