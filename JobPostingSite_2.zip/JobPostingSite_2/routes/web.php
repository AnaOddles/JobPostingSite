<?php
/*
 * Name: Mann Jaiswal, Kacey Morris, Ana Sanchez
 * Php 3 Laravel
 * All work is our as influenced  by in class lecture
 */
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Routes the user to the home page
Route::get('/', function () {
    return view('welcome');
});


//AUTH ROUTES

//Routes the user for authorization on login and register
Auth::routes();

//GET route for logging out
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');

//home page route
Route::get('/home', 'HomeController@index')->name('home');




//PROFILE ROUTES 

//GET Route to view the user profile
Route::get('/profiles/{user}', 'ProfilesController@index')->name('profile.show');

//GET route to edit profile
Route::get('/profile/{user}/edit', 'ProfilesController@edit')->name('profile.edit');

//PATCH route to update the user profile
Route::patch('/profile/{user}', 'ProfilesController@update')->name('profile.update');





//ADMIN ROUTES 

//GET route for the admin page
Route::get('/admin', 'AdminController@admin')
//uses the middleware for admin
->middleware('is_admin')
->name('admin');

Route::patch('admin/{user}/updateRole' ,'AdminController@updateRole')->name('user.roleUpdate');

Route::patch('admin/{user}/suspendUser','AdminController@suspendUser')->name('user.suspendUser'); 

Route::patch('admin/{user}/deleteUser','AdminController@deleteUser')->name('user.deleteUser');

//Admin job posting routes
Route::get('jobposting/create', 'JobPostingsController@create')->name('createJob')
->middleware('is_admin')
->name('admin');

//Route for Admin to see jobs
Route::get('admin/jobs', 'AdminController@showAdmin')
->middleware('is_admin')
->name('admin.jobs');
//uses the middleware for admin




//JOB POSTING ROUTES
Route::post('admin/{jobID}/editJob', "AdminController@editJob")->name('editjob')
//uses the middleware for admin
->middleware('is_admin')
->name('admin');

Route::patch('admin/{jobID}/updateJob', "AdminController@updateJob")->name('updatejob');

Route::patch('admin/{jobID}/deleteJob', "AdminController@deleteJob")->name('deleteJob')
->middleware('is_admin')
->name('admin');

//Route to see all jobs
Route::get('jobs', 'JobPostingsController@show')->name('jobposting.show')
->middleware('auth');

//POST route to actaully store the jobs into the database
Route::post('/addjobposting', 'JobPostingsController@store')
->middleware('is_admin')
->name('storeJobAdmin');

//GET Route to view a single jobpoosting
Route::get('/jobposting/{job}', 'JobPostingsController@index')->name('job.show')
->middleware('auth');

//POST Route to search for a job 
Route::post('/searchJob', 'JobPostingsController@searchJobs')->name('jobSearch')
->middleware('auth');








 //JOB APPLICATION ROUTES 
Route::post('applyJob/{job}', 'JobApplicationController@createJobApplication')->name('applyJob_1')
->middleware('auth');

Route::post('/applicationInformation{jobTitle}', 'JobApplicationController@info')->name('applyJob_2')
->middleware('auth');



//PORTFOLIO ROUTES

//GET Route to view the user profile
Route::get('/portfolios/{user}', 'PortfoliosController@index')->name('portfolio.show')
->middleware('auth');
//GET route to edit profile
Route::get('/portfolio/{user}/edit', 'PortfoliosController@edit')->name('portfolio.edit');
//PATCH route top update the user portfolio
Route::patch('/portfolio/{user}', 'PortfoliosController@update')->name('portfolio.update');

Route::any('any', function()
{
    return "Anything is possiblr if you try hard!";
});


// AFFINITY GROUP ROUTES
//Route to see all groups / NOT admin dependent
Route::get('affinitygroups', 'AffinityGroupsController@show')->name('affinitygroups.show')
->middleware('auth');

// ADMIN POST route to actaully store the group into the database
Route::post('/addaffinitygroup', 'AffinityGroupsController@store')
->middleware('is_admin')
->name('storeGroupAdmin');

// admin for new affinity group
Route::get('newaffinitygroup', 'AffinityGroupsController@create')
->middleware('is_admin')
->name('newaffinitygroup');

//Route for Admin to see groups
Route::get('admin/groups', 'AdminController@showGroupsAdmin')
->middleware('is_admin')
->name('admingroups');
//uses the middleware for admin

//Route to see all groups / NOT admin dependent
Route::post('showonegroup/{groupid}', 'AffinityGroupsController@showone')->name('affinitygroups.showone')
->middleware('auth');

// {userid}/{groupid}
Route::post('joingroup', "AffinityGroupsController@joinGroup")->name('joingroup')
->middleware('auth');

// for edit form group
Route::post('admin/{groupID}/editGroup', "AdminController@editGroup")->name('editgroupadmin')
//uses the middleware for admin
->middleware('is_admin');

// to delete group
Route::patch('admin/{groupID}/deleteGroup', "AdminController@deleteGroup")->name('deletegroupadmin')
->middleware('is_admin');

// to update group from edit form
Route::patch('admin/{groupID}/updateGroup', "AdminController@updateGroup")->name('updategroup')
->middleware('is_admin');

//Route to remove a group member / NOT admin dependent
Route::patch('removegroupmember', 'AffinityGroupsController@removeGroupMember')->name('removegroupmember')
->middleware('auth');

//Route to remove a group member / NOT admin dependent
Route::patch('removegroupmemberadmin', 'AdminController@removeGroupMember')->name('removegroupmemberadmin')
->middleware('is_admin');








