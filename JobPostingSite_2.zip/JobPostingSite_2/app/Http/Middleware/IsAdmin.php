<?php

namespace App\Http\Middleware;

use Closure;

class IsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        //IF the user is an admin
        if(auth()->user()->isAdmin()) {
            //take to next request - which is admin page
            return $next($request);
        }
        //else return home
        return redirect('home');
    }
}
