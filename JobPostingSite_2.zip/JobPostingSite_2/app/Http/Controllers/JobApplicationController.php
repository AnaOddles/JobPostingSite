<?php

namespace App\Http\Controllers;

use App\JobApplication;
use App\JobApplicationContactInfo;
use App\JobApplicationQualifications;
use App\services\business\JobApplicationBusiness;
use App\services\business\JobPostingsBusiness;

class JobApplicationController extends Controller
{
    
    /**
     * Controller method for user to create job application
     * @param  $jobPostingID
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function createJobApplication($jobPostingID)
    {
        //Create a job application obj
         $jobApplication = new JobApplication();
         $jobApplication->setJobPostingID($jobPostingID);
         $jobApplication->setUserID(auth()->user()->id);
         
         //Make an instance of business layer for job application
         $jobApplicationData = new JobApplicationBusiness();
         
         //Make an instance of job posting business for job posting
         $jobPostingData = new JobPostingsBusiness();
         
         //Create job application and grab the ID
         $jobApplicationId = $jobApplicationData->createJob($jobApplication);
         
         
         //grab the job posting using the ID passed in fro route
         $jobPostingID = (int)$jobPostingID;
         $jobPostings = $jobPostingData->getJob($jobPostingID);
         
           
         return view('/jobapplication/apply1')->with('jobApplicationId', $jobApplicationId)
         ->with('jobPostings', $jobPostings);
         
    }
    
    
    /**
     * Controller method for submitting a job application
     * @param  $jobTitle
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function info($jobTitle)
    {
        //Make instance of job application obj
        $jobApplication = new JobApplication();
        
        //Get form inputs
        $firstName = request()->get('firstName');
        $lastName = request()->get('lastName');
        $email = request()->get('email');
        
        $jobApplication->setFirstName($firstName);
        $jobApplication->setLastName($lastName);
        $jobApplication->setEmail($email);
        
        //grab job application ID passed from form
        $jobApplicationId = request()->get('jobApplicationID');
        
        $address = request()->get('address');
        $state = request()->get('state');
        $city = request()->get('city');
        $country = request()->get('country');
        $zipCode = request()->get('zipCode');
        $phone = request()->get('phone');
        
        
        //Create instance of the contactInfo for job application
        $contactInfo = new JobApplicationContactInfo($jobApplicationId, $address, $city,
            $state, $country, $zipCode, $phone);
        
        
        $education = request()->get('education');
        $licenseAndCertifications = request()->get('licenseAndCertifications');
        $skills = request()->get('skills');
        $experience = request()->get('experience');
        
        //Create an instance of job application qualifications
        $qualifications = new JobApplicationQualifications($jobApplicationId, $education,
            $licenseAndCertifications, $skills, $experience);
        
        //Make a new instance of job application business layer data
        $jobApplicationData = new JobApplicationBusiness();
        
        //Submit the job application passing in the info
        $jobApplicationData->submitInfo($jobApplication, $contactInfo, $qualifications);
        

        return view('jobapplication/apply2')->with('jobTitle', $jobTitle);
    }
    
    
}
