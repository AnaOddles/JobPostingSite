<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\JobPostings;
use App\User;
use App\services\business\AdminBusiness;
use App\services\business\JobPostingsBusiness;
use App\services\business\AffinityGroupsBusiness;
use App\AffinityGroup;


class AdminController extends Controller
{
    //Constructor with calling the admin
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    //controller method for the admin view
    public function admin()
    {
        $adminData = new AdminBusiness();
        
        $users = $adminData->getAllUsers();
        
        //returns view with all the users
        return view('admin/admin')->with('users', $users);
    }
    
    //controller method for the update user
    public function updateUser(User $user, string $suspended, string $type)
    {
        $adminData = new AdminBusiness();
        
        $adminData->updateUser($user, $type, $suspended);
        
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users);
    }
    
    
    //controller method to updateRole 
    public function updateRole(int $userID, Request $request)
    {
        $adminData = new AdminBusiness();
        
        $fields = Input::get("radio");
        if($fields == "admin")
        {
            $role = 'admin';
        }
        else
        {
            $role = 'default';
        }
        
        $adminData->updateRole($userID, $role);
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users); 
    }
    
    //controller method to susoend a user 
    public function suspendUser(int $userID)
    {
        $adminData = new AdminBusiness();
        
        $adminData->suspendUser($userID);
        
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users);
        
    }
    
    //controller method to delete user 
    public function deleteUser(int $userID)
    {
        $adminData = new AdminBusiness();
        
        $adminData->deleteUser($userID);
        
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users);
        
    }
    
    public function showAdmin()
    {
        $jobData = new JobPostingsBusiness();
        
        $jobs = $jobData->getAllJobs();
        
        return view('admin/adminjobs')->with('jobs', $jobs);
    }
    
    //controller method for the update job
    public function updateJob()
    {
        $jobData = new JobPostingsBusiness();
        
        
        $job = new JobPostings(request()->get('title'), request()->get('company'), request()->get('location'),
            request()->get('salary'), request()->get('description'), request()->get('type'),
            request()->get('postedOn'), request()->get('qualifications'));
        
        $job->setJobID(request()->get('id'));
        
        $jobData->updateJob($job);
        
        $jobs = $jobData->getAllJobs();
        
        return view('admin/adminjobs')->with('jobs', $jobs);
    }
    
    public function editJob(){
        
        $jobID = request()->get('id');
        $jobData = new JobPostingsBusiness();
        $jobs = $jobData->getJob($jobID);
        //$job->toArray();
        
        return view('admin/editJob')->with('jobs', $jobs);
    }
    
    //controller method to delete job
    public function deleteJob()
    {
        $jobData = new JobPostingsBusiness();
        
        $job = new JobPostings(request()->input('title'), request()->input('company'), request()->get('location'),
            request()->get('salary'), request()->get('description'), request()->get('type'),
            request()->get('postedOn'), request()->get('qualifications'));
        
        $job->setJobID(request()->get('id'));
        
        $jobData->deleteJob($job);
        
        $jobs = $jobData->getAllJobs();
        
        
        
        return view('admin/adminjobs')->with('jobs', $jobs);
        
    }
    public function showGroupsAdmin()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $groups = $groupsBusiness->getAllGroups();
        
        return view('admin/groups')->with('groups', $groups);
    }
    
    // function to edit group
    public function editGroup()
    {
        $groupID = request()->get('groupid');
        $groupsBusiness = new AffinityGroupsBusiness();
        $group = $groupsBusiness->getGroup($groupID);
        $members = $groupsBusiness->getMembers($groupID);
        
        return view('admin/editGroup')->with('group', $group)->with('members', $members);
    }
    
    //controller method to delete group
    public function deleteGroup()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $groupID = request()->get('groupid');
        
        $groupsBusiness->deleteGroup($groupID);
        
        $groups = $groupsBusiness->getAllGroups();
        
        return view('admin/groups')->with('groups', $groups);
        
    }
    
    //controller method for the update job
    public function updateGroup()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $group = new AffinityGroup(request()->get('grouptitle'), request()->get('groupdescription'));
        
        $group->setGroupID(request()->get('groupid'));
        
        $groupsBusiness->updateGroup($group);
        
        $groups = $groupsBusiness->getAllGroups();
        $members = $groupsBusiness->getMembers(request()->get('groupid'));
        
        return view('admin/groups')->with('groups', $groups)->with('members', $members);
    }
    
    //controller method to delete group
    public function removeGroupMember()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $groupID = request()->get('groupid');
        $userID = request()->get('userid');
        
        $groupsBusiness->removeGroupMember($userID, $groupID);
        
        $groups = $groupsBusiness->getAllGroups();
        
        return view('admin/groups')->with('groups', $groups);
        
    }
}
