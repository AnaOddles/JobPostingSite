<?php
namespace App\Http\Controllers;

use App\JobPostings;
use Illuminate\Http\Request;
use App\services\business\JobPostingsBusiness;

class JobPostingsController
{
    //Controller method to view the create post view
    public function create()
    {
        return view('jobposting/create');
    }
    
    /**
     * Method for creating a job posting into the database
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function store()
    {
        $job = new JobPostings(request()->get('title'), request()->get('company'), request()->get('location'), 
            request()->get('salary'), request()->get('description'), request()->get('type'), 
             date('Y-m-d'), request()->get('qualifications'));
        
        
        
        $jobData = new JobPostingsBusiness();
        
        $jobData->addJob($job);
        
        return redirect("/admin/jobs");
    }
    
    /**
     * Method to view all posted jobs
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function show()
    {
        $jobData = new JobPostingsBusiness();
        
        $jobs = $jobData->getAllJobs();
        
        return view('jobposting/index')->with('jobs', $jobs);
    }
    
    /**
     * Method to view a job posting
     * @param JobPostings $job
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function index(int $jobID)
    {
        $jobData = new JobPostingsBusiness();
        $jobs = $jobData->getJob($jobID);
        return view('jobposting/job')->with('jobs', $jobs);
        
    }
    
    /**
     * Method to search for a job posting
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function searchJobs()
    {
        $searchTerm = request()->get('searchTerm');
        $jobData = new JobPostingsBusiness();
        $jobs = $jobData->searchJobs($searchTerm);
        return view('jobposting/index')->with('jobs', $jobs);
    }
    
    
    
    
    
    
    
    
    
    
}

