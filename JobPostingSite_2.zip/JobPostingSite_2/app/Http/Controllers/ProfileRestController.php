<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\services\business\ProfileBusiness;
use App\Models\Api\ProfilesDTO;

class ProfileRestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $profileData = new ProfileBusiness();
        $DTO = new ProfilesDTO($profileData->getProfiles());
        
        return json_encode($DTO, JSON_PRETTY_PRINT);
    }

   
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    
}
