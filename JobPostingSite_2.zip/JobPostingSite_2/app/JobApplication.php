<?php
namespace App;

class JobApplication
{
    private $applicationId;
    private $jobPostingID;
    private $userID;
    private $firstName;
    private $lastName;
    private $email;
    //private $eighteenOrMore;
    //private $requireSponsorship;
    //private $backgtoundCheckConsent;
    //private $convictedOfCrime;
    //private $startDate;
    
    
/**
     * @return mixed
     */
    public function getJobPostingID()
    {
        return $this->jobPostingID;
    }

    /**
     * @return mixed
     */
//     public function getRequireSponsorship()
//     {
//         return $this->requireSponsorship;
//     }

    /**
     * @param mixed $jobPostingID
     */
    public function setJobPostingID($jobPostingID)
    {
        $this->jobPostingID = $jobPostingID;
    }

    /**
     * @param mixed $requireSponsorship
     */
//     public function setRequireSponsorship($requireSponsorship)
//     {
//         $this->requireSponsorship = $requireSponsorship;
//     }

    //     public function __construct($userID, $firstName, $lastName, 
//         $email, $eighteenOrMore, $requireSponsorship, $backgrouundCheckConsent,
//         $convinctedOfCrime, $startDate)
//     {
//         $this->userID = $userID;
//         $this->firstName = $firstName;
//         $this->lastName = $lastName;
//         $this->email = $email;
//         $this->eighteenOrMore = $eighteenOrMore;
//         $this->requireSponsorship = $requireSponsorship;
//         $this->backgtoundCheckConsent = $backgrouundCheckConsent;
//         $this->convictedOfCrime = $convinctedOfCrime;
//         $this->startDate = $startDate;
//     }
    /**
     * @return mixed
     */
    public function getApplicationId()
    {
        return $this->applicationId;
    }

    /**
     * @return mixed
     */
    public function getUserID()
    {
        return $this->userID;
    }

    /**
     * @return mixed
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * @return mixed
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * @return mixed
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * @return mixed
     */
//     public function getEighteenOrMore()
//     {
//         return $this->eighteenOrMore;
//     }

    /**
     * @return mixed
     */
//     public function getRequire_sponsorship()
//     {
//         return $this->require_sponsorship;
//     }

    /**
     * @return mixed
     */
//     public function getBackgtoundCheckConsent()
//     {
//         return $this->backgtoundCheckConsent;
//     }

    /**
     * @return mixed
     */
//     public function getConvictedOfCrime()
//     {
//         return $this->convictedOfCrime;
//     }

    /**
     * @return mixed
     */
//     public function getStartDate()
//     {
//         return $this->startDate;
//     }

    /**
     * @param mixed $applicationId
     */
    public function setApplicationId($applicationId)
    {
        $this->applicationId = $applicationId;
    }

    /**
     * @param mixed $userID
     */
    public function setUserID($userID)
    {
        $this->userID = $userID;
    }

    /**
     * @param mixed $firstName
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;
    }

    /**
     * @param mixed $lastName
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;
    }

    /**
     * @param mixed $email
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

    /**
     * @param mixed $eighteenOrMore
     */
//     public function setEighteenOrMore($eighteenOrMore)
//     {
//         $this->eighteenOrMore = $eighteenOrMore;
//     }

    /**
     * @param mixed $require_sponsorship
     */
//     public function setRequire_sponsorship($require_sponsorship)
//     {
//         $this->require_sponsorship = $require_sponsorship;
//     }

    /**
     * @param mixed $backgtoundCheckConsent
     */
//     public function setBackgtoundCheckConsent($backgtoundCheckConsent)
//     {
//         $this->backgtoundCheckConsent = $backgtoundCheckConsent;
//     }

    /**
     * @param mixed $convictedOfCrime
     */
//     public function setConvictedOfCrime($convictedOfCrime)
//     {
//         $this->convictedOfCrime = $convictedOfCrime;
//     }

    /**
     * @param mixed $startDate
     */
//     public function setStartDate($startDate)
//     {
//         $this->startDate = $startDate;
//     }

    //A job application has a user 
    public function user()
    {
        return $this->hasOne(User::class);
    }
    
    
    
    //A job application has contact information
    public function jobAppplicationContactInfo()
    {
        return $this->hasOne(JobApplicationContactInfo::class);
    }
    
    public function jobApplicationQualifications()
    {
        return $this->hasOne(JobApplicationQualifications::class);
    }
}

