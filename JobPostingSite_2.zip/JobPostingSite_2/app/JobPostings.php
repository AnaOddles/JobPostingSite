<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JobPostings extends Model
{
    protected $guarded = [];
    
    //Later implement a conpany model and each company will have
    //job postings
    
    //companies are the only ones that can edit and delete postings
    
    //adminds can delete all job postings
    
   private $jobID;
   private $title;
   private $company;
   private $location;
   private $salary;
   private $description;
   private $type;
   private $postedOn;
   private $qualifications;
   
   public function __construct($title, $company, $location, $salary,
       $description, $type, $postedOn, $qualifications)
   {
       $this->title = $title;
       $this->company = $company;
       $this->location = $location;
       $this->salary = $salary;
       $this->description = $description;
       $this->type = $type;
       $this->postedOn = $postedOn;
       $this->qualifications = $qualifications;
   }
   
   /**
    * @return mixed
    */
   public function getCompany()
   {
       return $this->company;
   }
   
   /**
    * @param mixed $company
    */
   public function setCompany($company)
   {
       $this->company = $company;
   }
   
   /**
    * @return mixed
    */
   public function getJobID()
   {
       return $this->jobID;
   }
   
   /**
    * @param mixed $jobID
    */
   public function setJobID($jobID)
   {
       $this->jobID = $jobID;
   }
   
/**
     * @return array
     */
    public function getGuarded()
    {
        return $this->guarded;
    }

/**
     * @return mixed
     */
    public function getTitle()
    {
        return $this->title;
    }  

/**
     * @return mixed
     */
    public function getLocation()
    {
        return $this->location;
    }

/**
     * @return mixed
     */
    public function getSalary()
    {
        return $this->salary;
    }

/**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

/**
     * @return mixed
     */
    public function getType()
    {
        return $this->type;
    }

/**
     * @return mixed
     */
    public function getPostedOn()
    {
        return $this->postedOn;
    }

/**
     * @return mixed
     */
    public function getQualifications()
    {
        return $this->qualifications;
    }

/**
     * @param array $guarded
     */
    public function setGuarded($guarded)
    {
        $this->guarded = $guarded;
    }

/**
     * @param mixed $title
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }

/**
     * @param mixed $location
     */
    public function setLocation($location)
    {
        $this->location = $location;
    }

/**
     * @param mixed $salary
     */
    public function setSalary($salary)
    {
        $this->salary = $salary;
    }

/**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

/**
     * @param mixed $type
     */
    public function setType($type)
    {
        $this->type = $type;
    }

/**
     * @param mixed $postedOn
     */
    public function setPostedOn($postedOn)
    {
        $this->postedOn = $postedOn;
    }

/**
     * @param mixed $qualifications
     */
    public function setQualifications($qualifications)
    {
        $this->qualifications = $qualifications;
    }
    
    
    

   
   
    
}
