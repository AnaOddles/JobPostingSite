<?php

namespace App\Policies;

use App\User;
use App\Portfolios;
use Illuminate\Auth\Access\HandlesAuthorization;

class PortfoliosPolicy
{
    use HandlesAuthorization;
    
    /**
     * Determine whether the user can view any portfolios.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function viewAny(User $user)
    {
        //
    }

    /**
     * Determine whether the user can view the portfolios.
     *
     * @param  \App\User  $user
     * @param  \App\Portfolios  $portfolios
     * @return mixed
     */
    public function view(User $user, Portfolios $portfolio)
    {
        //
    }

    /**
     * Determine whether the user can create portfolios.
     *
     * @param  \App\User  $user
     * @return mixed
     */
    public function create(User $user)
    {
        //
    }

    /**
     * Determine whether the user can update the portfolios.
     *
     * @param  \App\User  $user
     * @param  \App\Portfolios  $portfolios
     * @return mixed
     */
    public function update(User $user, Portfolios $portfolio)
    {
        return $user->id == $portfolio->user_id;
    }

    /**
     * Determine whether the user can delete the portfolios.
     *
     * @param  \App\User  $user
     * @param  \App\Portfolios  $portfolios
     * @return mixed
     */
    public function delete(User $user, Portfolios $portfolio)
    {
        //
    }

    /**
     * Determine whether the user can restore the portfolios.
     *
     * @param  \App\User  $user
     * @param  \App\Portfolios  $portfolios
     * @return mixed
     */
    public function restore(User $user, Portfolios $portfolio)
    {
        //
    }

    /**
     * Determine whether the user can permanently delete the portfolios.
     *
     * @param  \App\User  $user
     * @param  \App\Portfolios  $portfolios
     * @return mixed
     */
    public function forceDelete(User $user, Portfolios $portfolio)
    {
        //
    }
}
