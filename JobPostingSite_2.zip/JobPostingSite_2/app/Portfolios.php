<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Portfolios extends Model
{
    protected $guarded = [];
    
    //One to one relationship with profile
    
    //Profile also contains a user model
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
