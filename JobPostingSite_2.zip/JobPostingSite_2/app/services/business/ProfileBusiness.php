<?php
namespace App\services\business;

use App\User;
use App\services\data\ProfileData;

class ProfileBusiness
{
    private $profileData; 
    
    public function editProfile(User $user)
    {
        $this->profileData = new ProfileData();
        return $this->profileData->edit($user);
    }
   
    public function updateProfile(User $user){
        $this->profileData = new ProfileData();
        return $this->profileData->update($user);
        
    }
}

