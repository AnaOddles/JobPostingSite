<?php
namespace App\services\business;

use App\services\data\JobApplicationsData;

class JobApplicationBusiness
{
    
    private $jobApplicationData;
    
    /**
     * Business to create a new job application
     * @param $jobApplication
     * @return number
     */
    public function createJob($jobApplication)
    {
        $this->jobApplicationData = new JobApplicationsData();
        return $this->jobApplicationData->createJob($jobApplication);    
    }
    
    /**
     * Business to submit job application info and application
     * @param $jobApplication
     * @param $contactInfo
     * @param $qualifications
     */
    
    public function submitInfo($jobApplication, $contactInfo, $qualifications)
    {
        $this->jobApplicationData = new JobApplicationsData();
        $this->jobApplicationData->submitGeneralInfo($jobApplication, $contactInfo, $qualifications);
        
    }
    

    
   
}

