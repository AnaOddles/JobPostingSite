<?php
namespace App\services\business;
use App\services\data\JobPostingsData;
use App\JobPostings;

class JobPostingsBusiness
{
    private $jobsData;
    
    /**
     * Business Layer - Grabs all Jobs
     * @return \Illuminate\Support\Collection
     */
    public function getAllJobs()
    {
        $this->jobsData = new JobPostingsData();
        return $this->jobsData->getAllJobPostings();
    }
    
    public function addJob(JobPostings $job)
    {
        $this->jobsData = new JobPostingsData();
        $this->jobsData->addJob($job);
    }
    
    public function updateJob(JobPostings $job)
    {
        $this->jobsData = new JobPostingsData();
        $this->jobsData->updateJob($job);
    }
    
    public function deleteJob(JobPostings $job)
    {
        $this->jobsData = new JobPostingsData();
        $this->jobsData->deleteJob($job);
    }
    
    public function getJob(int $jobID)
    {
        $this->jobsData = new JobPostingsData();
        return $this->jobsData->getJob($jobID);
    }
}


