<?php
namespace App\services\data;

use Illuminate\Support\Facades\DB;
use App\JobPostings;

class JobPostingsData
{
    /**
     * Data access for grabbing all users
     * @return \Illuminate\Support\Collection
     */
    public function getAllJobPostings()
    {
        return DB::table('jobpostings')->select('*')->get(); 
    }
    
    /**
     * Data access tpo add a job
     * @param JobPostings $job
     */
    public function addJob(JobPostings $job)
    {
        DB::table('jobpostings')->insert([
            'title' => $job->getTitle(), 
            'company' => $job->getCompany(),
                'location' => $job->getLocation(), 
                'salary' => $job->getSalary(),
                'description' => $job->getDescription(),
                'type' => $job->getType(),
                 'postedOn' => $job->getPostedOn(),
                  'qualifications' => $job->getQualifications()]);
    }
    
    /**
     * Data access too update a job
     * @param JobPostings $job
     */
    public function updateJob(JobPostings $job)
    {
        DB::table('jobpostings')
        ->where('id', $job->getJobID())
        ->update(
            ['title' => $job->getTitle(),
            'company' => $job->getCompany(),
            'location' => $job->getLocation(),
            'salary' => $job->getSalary(),
            'description' => $job->getDescription(),
            'type' => $job->getType(),
            'postedOn' => $job->getPostedOn(),
            'qualifications' => $job->getQualifications()      
        ]);
    }
    
    /**
     * Data access to delete a job
     * @param JobPostings $job
     */
   public function deleteJob(JobPostings $job)
   {
       DB::table('jobpostings')->where('id', $job->getJobID())->delete();
   }
   
   public function getJob($jobID)
   {
       $job = DB::table('jobpostings')->select('*')
                   ->where('id', $jobID)->get();
       
       return $job;
   }
   
  /**
   * Data access to search for a job
   * @param $searchTerm
   * @return \Illuminate\Support\Collection
   */
   public function searchJobs($searchTerm)
   {
       return DB::table('jobpostings')
       ->select('*')
       ->where('description', 'LIKE', '%' . $searchTerm . '%')
       ->orWhere('title', 'LIKE', '%' . $searchTerm . '%')
       ->orWhere('company', 'LIKE', '%' . $searchTerm . '%')
       ->orWhere('location', 'LIKE', '%' . $searchTerm . '%')
       ->orWhere('type', 'LIKE', '%' . $searchTerm . '%')
       ->get();    
   }
   
   /**
    * Data access to grab an offset of jobs, limit to 20
    * @param $offset
    * @return \Illuminate\Support\Collection
    */
   public function getJobsOffset($offset)
   {
       return DB::table('jobpostings')
       //uses offset to start at a specific id
       ->offset($offset-1)
       //limits the results to 20
       ->limit(20)
       ->get();                                         
   }
   
   
    
    
}


