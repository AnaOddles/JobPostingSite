<?php
namespace App;

class JobApplicationContactInfo
{
    //Properties
    private $jobApplicationContactInfoID;
    private $address;
    private $jobApplicationID;
    private $city;
    private $state;
    private $country;
    private $zipCode;
    private $phone;
    
    //Contructor paramterized
    public function __construct($jobApplicationId, $address, $city, 
        $state, $country, $zipCode, $phone)
    {
        $this->jobApplicationID = $jobApplicationId;
        $this->address = $address;
        $this->city = $city; 
        $this->state = $state; 
        $this->country = $country; 
        $this->zipCode = $zipCode;
        $this->phone = $phone;
    }
    
    /**
     * @return mixed
     */
    public function getJobApplicationContactInfoID()
    {
        return $this->jobApplicationContactInfoID;
    }

    /**
     * @return mixed
     */
    public function getAddress()
    {
        return $this->address;
    }

    /**
     * @return mixed
     */
    public function getJobApplicationID()
    {
        return $this->jobApplicationID;
    }

    /**
     * @return mixed
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @return mixed
     */
    public function getState()
    {
        return $this->state;
    }

    /**
     * @return mixed
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * @return mixed
     */
    public function getZipCode()
    {
        return $this->zipCode;
    }

    /**
     * @return mixed
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @param mixed $jobApplicationContactInfoID
     */
    public function setJobApplicationContactInfoID($jobApplicationContactInfoID)
    {
        $this->jobApplicationContactInfoID = $jobApplicationContactInfoID;
    }

    /**
     * @param mixed $address
     */
    public function setAddress($address)
    {
        $this->address = $address;
    }

    /**
     * @param mixed $jobApplicationID
     */
    public function setJobApplicationID($jobApplicationID)
    {
        $this->jobApplicationID = $jobApplicationID;
    }

    /**
     * @param mixed $city
     */
    public function setCity($city)
    {
        $this->city = $city;
    }

    /**
     * @param mixed $state
     */
    public function setState($state)
    {
        $this->state = $state;
    }

    /**
     * @param mixed $country
     */
    public function setCountry($country)
    {
        $this->country = $country;
    }

    /**
     * @param mixed $zipCode
     */
    public function setZipCode($zipCode)
    {
        $this->zipCode = $zipCode;
    }

    /**
     * @param mixed $phone
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }

    //A JobApplicationContactInfo contains a job applicatio model 
    public function jobApplication()
    {
        return $this->belongsTo(JobApplication::class);
    }
    
}

