<?php
/*
 * Name: Mann Jaiswal, Kacey Morris, Ana Sanchez
 * Php 3 Laravel
 * All work is our as influenced  by in class lecture
 */
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Routes the user to the home page
Route::get('/', function () {
    return view('welcome');
});

//Routes the user for authorization on login and register
Auth::routes();

//home page route
Route::get('/home', 'HomeController@index')->name('home');

//GET Route to view the user profile
Route::get('/profiles/{user}', 'ProfilesController@index')->name('profile.show');

//GET route to edit profile
Route::get('/profile/{user}/edit', 'ProfilesController@edit')->name('profile.edit');

//PATCH route to update the user profile
Route::patch('/profile/{user}', 'ProfilesController@update')->name('profile.update');

//GET route for the admin page
Route::get('/admin', 'AdminController@admin')
->middleware('is_admin')
->name('admin');