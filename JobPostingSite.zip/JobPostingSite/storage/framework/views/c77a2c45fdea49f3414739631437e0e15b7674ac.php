 

<?php $__env->startSection('content'); ?>
<div class="container">
	<form action="/profile/<?php echo e($user->id); ?>" enctype="multipart/form-data" method="post">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PATCH'); ?>
		<div class="row">
			<div class="col-8 offset-2">
				<div class="row">
					<h1>Edit Profile</h1>
				</div>
				<!-- Div for headline -->
				<div class="form-group row">
					<label for="title" class="col-md-4 col-form-label">Headline</label>


					<input id="headline" type="text"
						class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
						name="headline" value="<?php echo e(old('headline') ?? $user->profile->headline); ?>" required
						autocomplete="headline" autofocus> <?php if ($errors->has('headline')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('headline'); ?> <span
						class="invalid-feedback" role="alert"> <strong><?php echo e($message); ?></strong>
					</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<!-- End of Div for headline  -->
				
				<!-- Div for about -->
				<div class="form-group row">
					<label for="about" class="col-md-4 col-form-label">About</label>


					<input id="about" type="text"
						class="form-control <?php if ($errors->has('about')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
						name="about" value="<?php echo e(old('about') ?? $user->profile->about); ?>" required
						autocomplete="about" autofocus> <?php if ($errors->has('about')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('about'); ?> <span
						class="invalid-feedback" role="alert"> <strong><?php echo e($message); ?></strong>
					</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<!-- End of Div for about  -->
				
				<!-- Div for location -->
				<div class="form-group row">
					<label for="url" class="col-md-4 col-form-label">Location</label>


					<input id="location" type="text"
						class="form-control <?php if ($errors->has('location')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('location'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
						name="location" value="<?php echo e(old('location') ?? $user->profile->location); ?>" required
						autocomplete="location" autofocus> <?php if ($errors->has('url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('url'); ?> <span
						class="invalid-feedback" role="alert"> <strong><?php echo e($message); ?></strong>
					</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<!-- End of Div for location  -->
				
				<!-- Div for about -->
				<div class="form-group row">
					<label for="education" class="col-md-4 col-form-label">Education</label>


					<input id="about" type="text"
						class="form-control <?php if ($errors->has('education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
						name="education" value="<?php echo e(old('education') ?? $user->profile->education); ?>" required
						autocomplete="education" autofocus> <?php if ($errors->has('education')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('education'); ?> <span
						class="invalid-feedback" role="alert"> <strong><?php echo e($message); ?></strong>
					</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<!-- End of Div for about  -->
				
					<!-- Div for licenseAndCertifications -->
				<div class="form-group row">
					<label for="licenseAndCertifications" class="col-md-4 col-form-label">License And Certications</label>


					<input id="licenseAndCertifications" type="text"
						class="form-control <?php if ($errors->has('licenseAndCertifications')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('licenseAndCertifications'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
						name="licenseAndCertifications" value="<?php echo e(old('licenseAndCertifications') ?? $user->profile->licenseAndCertifications); ?>" required
						autocomplete="licenseAndCertifications" autofocus> <?php if ($errors->has('licenseAndCertifications')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('licenseAndCertifications'); ?> <span
						class="invalid-feedback" role="alert"> <strong><?php echo e($message); ?></strong>
					</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<!-- End of Div for licenseAndCertifications  -->
				
				
				
					<!-- Div for skills -->
				<div class="form-group row">
					<label for="skills" class="col-md-4 col-form-label">Skills</label>


					<input id="skills" type="text"
						class="form-control <?php if ($errors->has('skills')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('skills'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
						name="skills" value="<?php echo e(old('skills') ?? $user->profile->skills); ?>" required
						autocomplete="skills" autofocus> <?php if ($errors->has('skills')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('skills'); ?> <span
						class="invalid-feedback" role="alert"> <strong><?php echo e($message); ?></strong>
					</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<!-- End of Div for skills  -->
				
				<!-- Div for experience -->
				<div class="form-group row">
					<label for="experience" class="col-md-4 col-form-label">Experience</label>


					<input id="experience" type="text"
						class="form-control <?php if ($errors->has('experience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('experience'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
						name="experience" value="<?php echo e(old('experience') ?? $user->profile->experience); ?>" required
						autocomplete="experience" autofocus> <?php if ($errors->has('experience')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('experience'); ?> <span
						class="invalid-feedback" role="alert"> <strong><?php echo e($message); ?></strong>
					</span> <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>
				
				<!-- End of Div for experience  -->
				
				
				<div class="row">
					<label for="image" class="col-md-4 col-form-label">Profile Image</label>
					<input type="file" class="form-control-file" id="image"
						name="image"> 
					<?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> 
					<strong><?php echo e($message); ?></strong>
					<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
				</div>

				<div class="row pt-4">
					<button class="btn btn-primary">Save Profile</button>
				</div>

			</div>
		</div>
	</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/anasanchez/CST-256/JobPostingSite/resources/views/profile/edit.blade.php ENDPATH**/ ?>