<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Portfolios;
use App\User;
use App\services\business\PortfolioBusiness;

class PortfoliosController extends Controller
{
    public function index(User $user)
    {
        return view('portfolio/index', compact('user'));
        
    }
    
    /**
     * returns view for editing the user portfolio
     * @param User $user
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function edit(User $user)
    {
        //Use the update poloicy to ensure that the user is the only 
        //that can update the portfolio
        $this->authorize('update', $user->portfolio);
        
        
        
        
        return view ('portfolio/edit', compact('user'));
        //$profileData = new ProfileBusiness();
        //return $profileData->editProfile($user); 
    }
    
    public function update(User $user)
    {
        $this->authorize('update', $user->portfolio);
        
                
            $portfolioData = new PortfolioBusiness();
            return $portfolioData->updatePortfolio($user);
            
        }
}
