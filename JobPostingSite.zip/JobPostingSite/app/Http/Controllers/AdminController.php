<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    //Constructor with calling the admin
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    //controller method for the admin view
    public function admin()
    {
        return view('admin/admin');
    }
}
