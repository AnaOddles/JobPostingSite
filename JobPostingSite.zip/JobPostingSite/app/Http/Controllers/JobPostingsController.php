<?php
namespace App\Http\Controllers;

use App\JobPostings;
use Illuminate\Http\Request;
use App\services\data\JobPostingsData;
use App\services\business\JobPostingsBusiness;

class JobPostingsController
{
    //Controller method to view the create post view
    public function create()
    {
        return view('jobposting/create');
    }
    
    public function store(Request $request)
    {
        $job = new JobPostings($request->input('title'), request()->get('location'), 
            request()->get('salary'), request()->get('description'), request()->get('type'), 
            request()->get('postedOn'), request()->get('qualifications'));
        
        $jobData = new JobPostingsBusiness();
        
        $jobData->addJob($job);
        
        return redirect("/admin");
    }
    
    public function show()
    {
        $jobData = new JobPostingsBusiness();
        
        $jobs = $jobData->getAllJobs();
        
        return view('jobposting/index')->with('jobs', $jobs);
    }
    
}

