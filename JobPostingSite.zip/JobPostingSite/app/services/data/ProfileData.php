<?php
namespace App\services\data;

use App\User;
use Intervention\Image\Facades\Image;

class ProfileData
{
    /**
     * Data access to view the edit of user profile
     * @param User $user
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function edit(User $user)
    {
        return view ('profile/edit', compact('user'));
    }
    
    /**
     * Data access to update user profile
     * @param User $user
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function update(User $user)
    {
        
        
        //Validating the data from the edit form
        //uses the rquest array
        $data = request()->validate([
            'headline' => 'required',
            'location' => 'required',
            //'education' => 'required',
            'about' => 'required',
            //'licenseAndCertifications' => 'required',
            //'skills' => 'required',
            //'experience' => 'required',
            
        ]);
        
        //if the user has an image
        if(request('image')){
            //grabbing the path of the image after saving it to the storage/app/public/uploads directory
            $imagePath = request('image')->store('/profile', 'public');
            
            //Using intervention/imgage class for configuration image
            $image = Image::make(public_path("storage/{$imagePath}"))->fit(1000,1000);
            $image->save();
            
            $imageArray = ['image' => $imagePath];
        }
        
        //makign sure to use the authorized users data for profile
        auth()->user()->profile->update(array_merge(
            $data,
            $imageArray ?? []
            
            ));
        
        return redirect("profiles/{$user->id}");
    }
    
}

