<?php
namespace App\services\data;

use App\User;

class PortfolioData
{
    /**
     * Data access for user to update their portfolio
     * @param User $user
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function update(User $user)
    {
        //Validating the data from the edit form
        //uses the rquest array
        $data = request()->validate([
            'education' => 'required',
            'licenseAndCertifications' => 'required',
            'skills' => 'required',
            'experience' => 'required',
            
        ]);
        
        
        //makign sure to use the authorized users data for profile
        auth()->user()->portfolio->update(array_merge(
            $data
            ));
        
        return redirect("portfolios/{$user->id}");
    }
}

