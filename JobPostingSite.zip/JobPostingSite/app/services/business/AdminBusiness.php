<?php
namespace App\services\business;

use App\User;
use App\services\data\AdminData;

class AdminBusiness
{
    private $adminData;
    
    /**
     * Business Layer - Grabs all Users 
     * @return \Illuminate\Support\Collection
     */
    public function getAllUsers()
    {
        $this->adminData = new AdminData();
        return $this->adminData->getAllUsers();
    }
    
    /**
     * Business Layer - Updates all Users 
     * @param User $user
     * @param string $type
     * @param bool $suspended
     */
    
    public function updateUser(User $user, string $type, bool $suspended)
    {
        $this->adminData = new AdminData();
        $this->adminData->updateUser($user, $type, $suspended);
    }
    
    
    /**
     * Business Layer - Deletes a Users 
     * @param User $user
     */
    public function deleteUser(int $userID)
    {
        $this->adminData = new AdminData();
        $this->adminData->deleteUser($userID);
    }
    
    
    /**
     * Business layer - update user role
     * @param int $userID
     * @param string $type
     */
    public function updateRole(int $userID, string $type)
    {
        $this->adminData = new AdminData();
        $this->adminData->updateRole($userID, $type );
    }
    
    
    /**
     * Business layer - suspend a user 
     * @param int $userID
     */
    public function suspendUser(int $userID)
    {
        $this->adminData = new AdminData();
        $this->adminData->suspend($userID);
    }
    
}

