<?php
/*
 * Name: Mann Jaiswal, Kacey Morris, Ana Sanchez 
 * Php 3 Laravel
 * All work is our as influenced  by in class lecture
 */
namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Profiles;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];
    
    //A user also has a profile model: one-to-one relationship
    public function profile()
    {
        return $this->hasOne(Profiles::class);
    }
    
    //function that gets booted up when we call the Model at any time
    protected static function boot()
    {
        parent::boot();
        
        //EVENT when a User is created
        static::created(function($user){
            //created a profile
            $user->profile()->create(
                [
                    //Set the title as as the username
                    'headline' => $user->name,
                ]);
        });
    }
}
