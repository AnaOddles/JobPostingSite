@extends('layouts.app') 

@section('content')
<div class="container">
	<form action="/profile/{{$user->id}}" enctype="multipart/form-data" method="post">
		@csrf
		@method('PATCH')
		<div class="row">
			<div class="col-8 offset-2">
				<div class="row">
					<h1>Edit Profile</h1>
				</div>
				<!-- Div for headline -->
				<div class="form-group row">
					<label for="title" class="col-md-4 col-form-label">Headline</label>


					<input id="headline" type="text"
						class="form-control @error('title') is-invalid @enderror"
						name="headline" value="{{ old('headline') ?? $user->profile->headline }}" required
						autocomplete="headline" autofocus> @error('headline') <span
						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong>
					</span> @enderror
				</div>
				
				<!-- End of Div for headline  -->
				
				<!-- Div for about -->
				<div class="form-group row">
					<label for="about" class="col-md-4 col-form-label">About</label>


					<input id="about" type="text"
						class="form-control @error('about') is-invalid @enderror"
						name="about" value="{{ old('about') ?? $user->profile->about }}" required
						autocomplete="about" autofocus> @error('about') <span
						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong>
					</span> @enderror
				</div>
				
				<!-- End of Div for about  -->
				
				<!-- Div for location -->
				<div class="form-group row">
					<label for="url" class="col-md-4 col-form-label">Location</label>


					<input id="location" type="text"
						class="form-control @error('location') is-invalid @enderror"
						name="location" value="{{ old('location') ?? $user->profile->location }}" required
						autocomplete="location" autofocus> @error('url') <span
						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong>
					</span> @enderror
				</div>
				
				<!-- End of Div for location  -->
				
				<!-- Div for education -->
<!-- 				<div class="form-group row"> -->
<!-- 					<label for="education" class="col-md-4 col-form-label">Education</label> -->


<!-- 					<input id="about" type="text" -->
<!-- 						class="form-control @error('education') is-invalid @enderror" -->
<!-- 						name="education" value="{{ old('education') ?? $user->profile->education}}" required -->
<!-- 						autocomplete="education" autofocus> @error('education') <span -->
<!-- 						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong> -->
<!-- 					</span> @enderror -->
<!-- 				</div> -->
				
				<!-- End of Div for education  -->
				
					<!-- Div for licenseAndCertifications -->
<!-- 				<div class="form-group row"> -->
<!-- 					<label for="licenseAndCertifications" class="col-md-4 col-form-label">License And Certications</label> -->


<!-- 					<input id="licenseAndCertifications" type="text" -->
<!-- 						class="form-control @error('licenseAndCertifications') is-invalid @enderror" -->
<!-- 						name="licenseAndCertifications" value="{{ old('licenseAndCertifications') ?? $user->profile->licenseAndCertifications }}" required -->
<!-- 						autocomplete="licenseAndCertifications" autofocus> @error('licenseAndCertifications') <span -->
<!-- 						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong> -->
<!-- 					</span> @enderror -->
<!-- 				</div> -->
				
				<!-- End of Div for licenseAndCertifications  -->
				
				
				
					<!-- Div for skills -->
<!-- 				<div class="form-group row"> -->
<!-- 					<label for="skills" class="col-md-4 col-form-label">Skills</label> -->


<!-- 					<input id="skills" type="text" -->
<!-- 						class="form-control @error('skills') is-invalid @enderror" -->
<!-- 						name="skills" value="{{ old('skills') ?? $user->profile->skills }}" required -->
<!-- 						autocomplete="skills" autofocus> @error('skills') <span -->
<!-- 						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong> -->
<!-- 					</span> @enderror -->
<!-- 				</div> -->
				
				<!-- End of Div for skills  -->
				
				<!-- Div for experience -->
<!-- 				<div class="form-group row"> -->
<!-- 					<label for="experience" class="col-md-4 col-form-label">Experience</label> -->


<!-- 					<input id="experience" type="text" -->
<!-- 						class="form-control @error('experience') is-invalid @enderror" -->
<!-- 						name="experience" value="{{ old('experience') ?? $user->profile->experience }}" required -->
<!-- 						autocomplete="experience" autofocus> @error('experience') <span -->
<!-- 						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong> -->
<!-- 					</span> @enderror -->
<!-- 				</div> -->
				
				<!-- End of Div for experience  -->
				
				
				<div class="row">
					<label for="image" class="col-md-4 col-form-label">Profile Image</label>
					<input type="file" class="form-control-file" id="image"
						name="image"> 
					@error('image') 
					<strong>{{ $message }}</strong>
					@enderror
				</div>

				<div class="row pt-4">
					<button class="btn btn-primary">Save Profile</button>
				</div>

			</div>
		</div>
	</form>
</div>
@endsection
