<?php
namespace App\services\data;

use Illuminate\Support\Facades\DB;

class JobApplicationsData
{
    /**
     * Data access to create a new job application
     * @param  $jobApplication
     * @return number
     */
    public function createJob($jobApplication)
    {
        return DB::table('jobapplication')->insertGetId([
            'user_id' => $jobApplication->getUserID(),
            'jobposting_id' => $jobApplication->getUserID(),
        ]);
    }
    
    /**
     * Data access to submit appplication
     * @param  $jobApplication
     * @param  $contactInfo
     * @param  $qualifications
     */
    public function submitGeneralInfo($jobApplication, $contactInfo, $qualifications)
    {
        DB::table('jobapplication')
        ->where('id', $contactInfo->getJobApplicationID())
        ->update(
            [
            'first_name' => $jobApplication->getFirstName(),
            'last_name' => $jobApplication->getLastName(),
            'email' => $jobApplication->getEmail()
            
        ]);
        
        
        DB::table('jobapplicationcontactinfo')->insert([
            'jobapplication_id' => $contactInfo->getJobApplicationID(),
            'address' => $contactInfo->getAddress(),
            'city' => $contactInfo->getCity(),
            'state' => $contactInfo->getState(),
            'country' => $contactInfo->getCountry(),
            'zip_code' => $contactInfo->getZipCode(),
            'phone' => $contactInfo->getPhone()
        ]);
        
        DB::table('jobapplicationqualifications')->insert([
            'jobapplication_id' => $qualifications->getJobApplicationID(),
            'education' => $qualifications->getEducation(),
            'licenseAndCertifications' => $qualifications->getLicenseAndCertifications(),
            'skills' => $qualifications->getSkills(),
            'experience' => $qualifications->getExperience(),
        ]);
    }
    
}

