<?php
namespace App\services\business;
use App\services\data\JobPostingsData;
use App\JobPostings;

class JobPostingsBusiness
{
    private $jobsData;
    
    /**
     * Business Layer - Grabs all Jobs
     * @return \Illuminate\Support\Collection
     */
    public function getAllJobs()
    {
        $this->jobsData = new JobPostingsData();
        return $this->jobsData->getAllJobPostings();
    }
    
    /**
     * Business layer - CRUD post a job
     * @param JobPostings $job
     */
    public function addJob(JobPostings $job)
    {
        $this->jobsData = new JobPostingsData();
        $this->jobsData->addJob($job);
    }
    
    /**
     * Business layer - CRUD update a job
     * @param JobPostings $job
     */
    public function updateJob(JobPostings $job)
    {
        $this->jobsData = new JobPostingsData();
        $this->jobsData->updateJob($job);
    }
    
    /**
     * Business layer - CRUD delete a job
     * @param JobPostings $job
     */
    public function deleteJob(JobPostings $job)
    {
        $this->jobsData = new JobPostingsData();
        $this->jobsData->deleteJob($job);
    }
    
    /**
     * Business layer - CRUD get a job
     * @param  $jobID
     * @return \Illuminate\Support\Collection
     */
    public function getJob($jobID)
    {
        $this->jobsData = new JobPostingsData();
        return $this->jobsData->getJob($jobID);
    }
    
    /**
     * Business layer - CRUD get a job with search term
     * @param $searchTerm
     * @return \Illuminate\Support\Collection
     */
    public function searchJobs($searchTerm)
    {
        $this->jobsData = new JobPostingsData();
        return $this->jobsData->searchJobs($searchTerm);
    }
    
    /**
     * Business layer - CRUD get 20 jobs with offset
     * @param $offset
     * @return \Illuminate\Support\Collection
     */
    public function getJobsOffset($offset)
    {
        $this->jobsData = new JobPostingsData();
        return $this->jobsData->getJobsOffset($offset);
    }
    
}


