<?php
namespace App\Models\Api;

use JsonSerializable;

class ProfilesDTO implements \JsonSerializable
{
    public $errorCode;
    public $errorMessage;
    public $data; 
    
    public function __construct($data)
    {
        $this->data = $data;
        
        //If there is no profiles passed 
        if($data == '[]')
        {
            $this->errorCode = "5053";
            $this->errorMessage = "No profiles found";
        }
        
        //Else grabbed profiles
        else
        {
            $this->errorCode ="200";
            $this->errorMessage ="OK - Success";
        }
        
    }
    
    //JsonSeralize interface method that returns obj as json format
    public function jsonSerialize()
    {
        return get_object_vars($this);
    }

}

