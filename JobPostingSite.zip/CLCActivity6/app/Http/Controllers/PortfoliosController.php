<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Portfolios;
use App\User;
use App\services\business\PortfolioBusiness;
use App\services\data\Utility\ILoggerService;

class PortfoliosController extends Controller
{
    
    //Injected logger service
    protected $logger;
    
    
    public function __construct(ILoggerService $logger)
    {
        
        $this->logger = $logger;
    }
    public function index(User $user)
    {
        $this->logger->info("Entering PortfoliosController@index");
        
        return view('portfolio/index', compact('user'));
        
    }
    
    /**
     * returns view for editing the user portfolio
     * @param User $user
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function edit(User $user)
    {
        $this->logger->info("Entering PortfoliosController@edit");
        
        //Use the update poloicy to ensure that the user is the only 
        //that can update the portfolio
        $this->authorize('update', $user->portfolio);
        
        return view ('portfolio/edit', compact('user'));
        //$profileData = new ProfileBusiness();
        //return $profileData->editProfile($user); 
    }
    
    /**
     * Method to update the portfolio
     * @param User $user
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function update(User $user)
    {
        $this->logger->info("Entering PortfoliosController@update");
        
        $this->authorize('update', $user->portfolio);
        
                
        $portfolioData = new PortfolioBusiness();
        return $portfolioData->updatePortfolio($user);
            
        }
}
