<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\services\business\ProfileBusiness;
use App\services\data\Utility\ILoggerService;
use App\Models\Api\ProfilesDTO;

class ProfileRestController extends Controller
{
    
    //Injected logger service
    protected $logger;
    
    
    public function __construct(ILoggerService $logger)
    {
        $this->logger = $logger;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $this->logger->info("Entering ProfilesRestController@index");
        
        $profileData = new ProfileBusiness();
        $DTO = new ProfilesDTO($profileData->getProfiles());
        
        return json_encode($DTO, JSON_PRETTY_PRINT);
    }

   
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $this->logger->info("Entering ProfilesRestController@show");
        
        //
    }

    
}
