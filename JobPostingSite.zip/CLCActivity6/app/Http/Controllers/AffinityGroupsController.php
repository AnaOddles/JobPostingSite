<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AffinityGroup;
use App\services\business\AffinityGroupsBusiness;
use App\services\data\Utility\ILoggerService;

class AffinityGroupsController
{
    //Injected logger service
    protected $logger;
    
    
    //Constructor with calling the affinity group controller
    public function __construct(ILoggerService $logger)
    {
        $this->logger = $logger;
    }
    
    //Controller method to view the create post view
    public function create()
    {
        $this->logger->info("Entering AffinityGroupsControllerController@create");
        
        return view('affinitygroup/create');
    }
    
    /**
     * Method for creating a job posting into the database
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'description'=> 'required'
        ]);
        
        $this->logger->info("Entering AffinityGroupsControllerCController@store");
        
        $group = new AffinityGroup(request()->get('title'), request()->get('description'));
        
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $groupsBusiness->addGroup($group);
        
        return redirect()->route('affinitygroups.show');
    }
    
    /**
     * Method to view all groups
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function show()
    {
        $this->logger->info("Entering AffinityGroupsControllerController@show");
        
    	$groupsBusiness = new AffinityGroupsBusiness();
        
    	$groups = $groupsBusiness->getAllGroups();
        
        return view('affinitygroup.index')->with('groups', $groups);
    } 
    
    public function showone($groupID) {
        $this->logger->info("Entering AffinityGroupsControllerController@showone");
        
    	$groupsBusiness = new AffinityGroupsBusiness();
    	
    	$group = $groupsBusiness->getGroup($groupID);
    	
    	$members = $groupsBusiness->getMembers($groupID);
    	
    	return view('affinitygroup/showone')->with('group', $group)->with('members', $members);
    }
    
    public function joinGroup() {
        $this->logger->info("Entering AffinityGroupsControllerController@joinGroup");
        
    	$userID = request()->get('userid');
    	$groupID = request()->get('groupid');
    	$groupsBusiness = new AffinityGroupsBusiness();
    	$groupsBusiness->joinGroup($userID, $groupID);
    	return redirect()->route('affinitygroups.show');
    }
    
    //controller method to delete group
    public function removeGroupMember()
    {
        $this->logger->info("Entering AffinityGroupsControllerController@removeGroupMember");
        
    	$groupsBusiness = new AffinityGroupsBusiness();
    	
    	$groupID = request()->get('groupid');
    	$userID = request()->get('userid');
    	
    	$groupsBusiness->removeGroupMember($userID, $groupID);
    	
    	$groups = $groupsBusiness->getAllGroups();
    	
    	return view('affinitygroup/index')->with('groups', $groups);
    	
    }
}

