<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use App\services\business\ProfileBusiness;
use App\services\data\Utility\ILoggerService;

class ProfilesController extends Controller
{
    protected $logger;
    
    
    public function __construct(ILoggerService $logger)
    {
        $this->logger = $logger;
    }
    

     public function index(User $user)
    {
        $this->logger->info("Entering ProfilesController@index");
        
        //Only allows users to view their own profiles
         //Uses 'view" policy
         $this->authorize('view', $user->profile);
        
        return view('profile/index', compact('user'));
        
  
     }
    
//     /**
//      * returns view for editing the user profile
//      * @param User $user
//      * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
//      */
    public function edit(User $user)
    {
        $this->logger->info("Entering ProfilesController@edit");
        
        $this->authorize('update', $user->profile);
//         $this->authorize('update', $user->profile);

        
        
        
//         return view ('profile/edit', compact('user'));
       $profileData = new ProfileBusiness();
       return $profileData->editProfile($user);
        
    }
    
    
    public function update(User $user)
    {
        $this->logger->info("Entering ProfilesController@update");
        
        $this->authorize('update', $user->profile);
//         $this->authorize('update', $user->profile);
        
//         //Validating the data from the edit form
//         //uses the rquest array
//         $data = request()->validate([
//             'headline' => 'required',
//             'location' => 'required',
//             'education' => 'required',
//             'about' => 'required',
//             'licenseAndCertifications' => 'required',
//             'skills' => 'required',
//             'experience' => 'required',
            
//         ]);
        
//         //if the user has an image
//         if(request('image')){
//             //grabbing the path of the image after saving it to the storage/app/public/uploads directory
//             $imagePath = request('image')->store('/profile', 'public');
            
//             //Using intervention/imgage class for configuration image
//             $image = Image::make(public_path("storage/{$imagePath}"))->fit(1000,1000);
//             $image->save();
            
//             $imageArray = ['image' => $imagePath];
//         }
        
//         //makign sure to use the authorized users data for profile
//         auth()->user()->profile->update(array_merge(
//             $data,
//             $imageArray ?? []
            
//             ));
        
//         return redirect("profiles/{$user->id}");
        $profileData = new ProfileBusiness();
        return $profileData->updateProfile($user);
        
    }
}
