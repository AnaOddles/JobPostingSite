<?php
namespace App;

class JobApplicationQualifications
{
    //Properties
    private $jobApplicationQualificationsID;
    private $jobApplicationId;
    private $education;
    private $licenseAndCertifications;
    private $skills;
    private $experience; 
    
    
    //Parameterized Constructor
    public function __construct($jobApplicationID, $education, $licenseAndCertifications,
       $skills, $experience) 
    {
        $this->jobApplicationId = $jobApplicationID;
        $this->education = $education;
        $this->licenseAndCertifications = $licenseAndCertifications;
        $this->skills = $skills;
        $this->experience = $experience;
    }
    
    //Getter and Setters
    /**
     * @return mixed
     */
    public function getJobApplicationQualificationsID()
    {
        return $this->jobApplicationQualificationsID;
    }

    /**
     * @return mixed
     */
    public function getJobApplicationId()
    {
        return $this->jobApplicationId;
    }

    /**
     * @return mixed
     */
    public function getEducation()
    {
        return $this->education;
    }

    /**
     * @return mixed
     */
    public function getLicenseAndCertifications()
    {
        return $this->licenseAndCertifications;
    }

    /**
     * @return mixed
     */
    public function getSkills()
    {
        return $this->skills;
    }

    /**
     * @return mixed
     */
    public function getExperience()
    {
        return $this->experience;
    }

    /**
     * @param mixed $jobApplicationQualificationsID
     */
    public function setJobApplicationQualificationsID($jobApplicationQualificationsID)
    {
        $this->jobApplicationQualificationsID = $jobApplicationQualificationsID;
    }

    /**
     * @param mixed $jobApplicationId
     */
    public function setJobApplicationId($jobApplicationId)
    {
        $this->jobApplicationId = $jobApplicationId;
    }

    /**
     * @param mixed $education
     */
    public function setEducation($education)
    {
        $this->education = $education;
    }

    /**
     * @param mixed $licenseAndCertifications
     */
    public function setLicenseAndCertifications($licenseAndCertifications)
    {
        $this->licenseAndCertifications = $licenseAndCertifications;
    }

    /**
     * @param mixed $skills
     */
    public function setSkills($skills)
    {
        $this->skills = $skills;
    }

    /**
     * @param mixed $experience
     */
    public function setExperience($experience)
    {
        $this->experience = $experience;
    }

    //A JobApplicationContactInfo contains a job applicatio model
    public function jobApplication()
    {
        return $this->belongsTo(JobApplication::class);
    }
}

