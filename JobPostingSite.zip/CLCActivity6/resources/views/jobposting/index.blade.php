@extends('layouts.app') 

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<div class="container">
	<h1>Job Postings</h1>
	<div style="float:right; margin-bottom: 9px;" >
	<form class="example" action="{{route('jobSearch')}}" style="margin:auto; max-width:300px" method="post">
	@csrf
  <input type="text" placeholder="Search.." name="searchTerm">
  <button type="submit"><i class="fa fa-search"></i></button>
</form>
  </div>

	<!-- start of the table -->

	<div class="container" padding="50px">

		<table class="table table-hover">

			<thead>

				<tr>

					<!-- table header data -->
					<!--<th scope="col">ID</th> -->

					<th scope="col">Title</th>
					<th scope="col">Date Posted</th>
					
					
					<th scope="col">Location</th>
					
					<th scope="col">Company</th>

					<!--<th scope="col">Salary</th>-->
					
					<!--<th scope="col">Description</th>-->
					
					<!--<th scope="col">Type</th>-->

				</tr>

			</thead>

			<tbody>
				<!-- populate the table with the appropriate user information -->
				<?php
				foreach ($jobs as $job) {
    				echo "<tr>"; 

    				//echo "<th scope='row'>" . $job->id . "</th>";
    				?>
    				<td><a href="{{route('job.show', ['job' => $job->id]) }}"><?php echo $job->title?></a></td>
    				<?php 
    				echo "<td>" . $job->postedOn . "</td>";
    				echo "<td>" . $job->location . "</td>";
    				echo "<td>" . $job->company . "</td>";
    				//echo "<td>" . $job->salary . "</td>";
    				//echo "<td>" . $job->description . "</td>";
    				//echo "<td>" . $job->type . "</td>";
    
    				echo "</tr>";
				}
				?>

			
			</tbody>

		</table>

	</div>

</div>
@endsection
