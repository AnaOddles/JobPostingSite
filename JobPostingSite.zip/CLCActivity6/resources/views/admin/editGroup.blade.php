@extends('layouts.app') @section('content')
<div class="container">
<form action="{{route('updategroup', ['groupID' => $group[0]->groupid]) }}" enctype="multipart/form-data" method="post">
		@csrf
		@Method("PATCH")
		<div class="row">
			<div class="col-8 offset-2">
				<div class="row">
					<h1><?php echo $group[0]->grouptitle?></h1>
				</div>
				
				<input type="hidden" name="groupid" value="<?php echo $group[0]->groupid?>">
				
				<div class="form-group row">
					<label for="grouptitle" class="col-md-4 col-form-label">Title:</label>
					<input id="grouptitle" type="text"
						class="form-control"
						name="grouptitle" value="<?php echo $group[0]->grouptitle?>"
						required
						autocomplete="grouptitle" autofocus> @error('grouptitle') <span
						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong>
					</span> @enderror
				</div>
		
				<div class="form-group row">
					<label for="groupdescription" class="col-md-4 col-form-label">Description:</label>
					<input id="groupdescription" type="text"
						class="form-control"
						name="groupdescription" value="<?php echo $group[0]->groupdescription?>"
						required
						autocomplete="groupdescription" autofocus> @error('groupdescription') <span
						class="invalid-feedback" role="alert"> <strong>{{ $message }}</strong>
					</span> @enderror
				</div>
				
				<div class="row pt-4">
				<button class="btn btn-primary">Update</button>
			</div>
		</form>
		<br>
		<div>
			<h4>Members</h4>
		</div>
		<div class="list-group">
			<?php foreach ($members as $member) { ?>
				<a href="{{ route('portfolio.show', ['user' => $member['userid'] ]) }}" class="list-group-item list-group-item-action"><?php echo $member['userid'] . " : " . $member['name'] ?></a>
				<!-- need an option to delete members from group -->
				<form action="{{route('removegroupmemberadmin') }}" method='post'>
					{{ csrf_field() }}
					@method("PATCH")
					<?php
						echo "<input type='hidden' name='groupid' value='" . $group[0]->groupid . "'>";
   						echo "<input type='hidden' name='userid' value='" . $member['userid'] . "'>";
   						echo "<input class='btn btn-danger' type='submit' name='submit' value='x'>";
   						echo "</form>";
					} ?>
		</div>
	</div>
</div>
</div>
@endsection
