<?php
namespace App\services\business;

use App\User;
use App\services\data\ProfileData;

class ProfileBusiness
{
    private $profileData; 
    
    /**
     * Business layer - open edit form
     * @param User $user
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function editProfile(User $user)
    {
        $this->profileData = new ProfileData();
        return $this->profileData->edit($user);
    }
   
    /**
     * Business layer - update CRUD for user profile
     * @param User $user
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function updateProfile(User $user){
        $this->profileData = new ProfileData();
        return $this->profileData->update($user);
        
    }
    
    /**
     * Business layer - CRUD get the user profile
     * @return \Illuminate\Support\Collection
     */
    public function getProfiles()
    {
        $this->profileData = new ProfileData();
        return $this->profileData->getAllProfiles();
    }
}

