<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\services\business\JobPostingsBusiness;
use App\services\data\Utility\ILoggerService;
use App\Models\Api\JobPostingDTO;

class JobPostingRestController extends Controller
{
    
    //Injected logger service
    protected $logger;
    
    
    public function __construct(ILoggerService $logger)
    {
        $this->logger = $logger;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function jobpostings($offset = 0)
    {
        $this->logger->info("Entering JobPostingRestController@jobpostings");
        
        $jobData = new JobPostingsBusiness();
        
        //if we pass the optional param of offset
        if($offset != 0)
        {
            //grab the next 20 job postings starting at the offset 
            $data = $jobData->getJobsOffset($offset);
        }
        else 
        {
            //else grab all 
            $data = $jobData->getAllJobs();
            
        }
        
        $DTO = new JobPostingDTO($data, null);
        return json_encode($DTO, JSON_PRETTY_PRINT);
    
        
    }

   /**
    * API reource displays a single job posting
    * @param  $id
    * @return string
    */
    public function show($id)
    {
        $this->logger->info("Entering JobPostingRestController@show");
        
        $jobData = new JobPostingsBusiness();
           
        $data = $jobData->getJob($id);
            
        $DTO = new JobPostingDTO($data, $id);
        return json_encode($DTO, JSON_PRETTY_PRINT);        
    }
    
}
