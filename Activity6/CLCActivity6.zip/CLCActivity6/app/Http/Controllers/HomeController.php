<?php

namespace App\Http\Controllers;

use App\services\data\Utility\ILoggerService;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    //Injected logger service
    protected $logger;
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct(ILoggerService $logger)
    {
        $this->middleware('auth');
        $this->logger = $logger;
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $this->logger->info("Entering HomeController@create");
        return view('home');
    }
}
