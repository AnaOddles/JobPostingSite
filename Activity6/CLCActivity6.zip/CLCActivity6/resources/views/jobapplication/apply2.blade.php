@extends('layouts.app') 
@section('content')
<div class="container">
		
		<div class="row">
			
			<div class="row pt-4" align="center">
					<h5>Thank you <?php echo auth()->user()->name?>! </h5><br/>
				</div>
			
			
			
		</div>
		<div class="row pt-4">
					<h6>Your application for <?php echo $jobTitle?> has been submitted.</h6>
				</div>
		</div>
	
@endsection

