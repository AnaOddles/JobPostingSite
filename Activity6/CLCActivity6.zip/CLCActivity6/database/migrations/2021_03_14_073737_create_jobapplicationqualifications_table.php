<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateJobapplicationqualificationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jobapplicationqualifications', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('jobapplication_id');
            $table->text('education')->nullable();
            $table->text('licenseAndCertifications')->nullable();
            $table->text('skills')->nullable();
            $table->text('experience')->nullable();
            
            
            //Index on foreign key - for user table
            $table->index('jobapplication_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jobapplicationqualifications');
    }
}
