<?php
namespace App\services\data;

/*
 * Ana Sanchez
 * Mann Jaiswal
 * Kacey Morris
 * Feb 28, 2021
 * CST 256
 * Job Posting Site - Milestone 4
 * This is our own work as influenced by class time and examples.
 */

use Illuminate\Support\Facades\DB;
use App\JobPostings;
use App\AffinityGroup;
use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class AffinityGroupsData
{
    // database connection
    private $dbObj;
    private $connection;
    private $dbQuery;
    /**
     * Data access for grabbing all groups
     * @return \Illuminate\Support\Collection
     */
    public function getAllGroups()
    {
    	// return all from the database for this table
        return DB::table('affinitygroup')->select('*')->get();
    }
    
    /**
     * Data access to add a group
     * @param JobPostings $job
     */
    public function addGroup(AffinityGroup $group)
    {
    	// insert into database table
        DB::table('affinitygroup')->insert([
            'grouptitle' => $group->getGroupTitle(),
            'groupdescription' => $group->getGroupDescription(),
        ]);
    }
    
    /**
     * Data access too update a group
     * @param JobPostings $job
     */
    public function updateGroup(AffinityGroup $group)
    {
    	// update properties in table
        DB::table('affinitygroup')
        ->where('groupid', $group->getGroupID())
        ->update(
            ['grouptitle' => $group->getGroupTitle(),
                'groupdescription' => $group->getGroupDescription()
            ]);
    }
    
    /**
     * Data access to delete a group
     * @param JobPostings $job
     */
    public function deleteGroup(int $groupID)
    {
    	// delete where group ID matches
    	// FOREIGN KEY CASCADE DELETES so members connected to this group will also be removed from/
    	// the group members table
        DB::table('affinitygroup')->where('groupid', $groupID)->delete();
    }
    
    /**
     * Data access to get one group by ID
     * @param JobPostings $job
     */
    public function getGroup(int $groupID)
    {
    	// get a single group from table
        $group = DB::table('affinitygroup')->select('*')
        ->where('groupid', $groupID)->get();
        
        return $group;
    }
    
    // get all members of the group with this ID
    public function getMembers($groupID) {
        // connect to the relationship database
        $this->dbObj = new DBConnect("jobpostingsite");
        $this->connection = $this->dbObj->getDbConnect();
        
        try {
            // define the query to submit to the database
            $this->dbQuery = "SELECT userid, name
							FROM groupmembers gm
							JOIN users u
							ON u.id = gm.userid
							WHERE groupid = " . $groupID;
            
            // save the result of the query 
            $result = mysqli_query($this->connection, $this->dbQuery);
            
            // add members to array
            $members = Array();
            
            // push to array 
            while ($member = $result->fetch_assoc()) {
                array_push($members, $member);
            }
            
            // return members array 
            return $members;
        }
        // exception handling
        catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
    // data access to join a group
    public function joinGroup($userID, $groupID) {
        // connect to the relationship database
        $this->dbObj = new DBConnect("jobpostingsite");
        $this->connection = $this->dbObj->getDbConnect();
        
        try {
            // define the query to submit to the database
            $this->dbQuery = "INSERT INTO groupmembers
								VALUES (
									" . $groupID . ",
									" . $userID . "
								)";
            
            // if the query works
            if (mysqli_query($this->connection, $this->dbQuery)) {
                // $this->conn->closeDbConnect();
                return true;
            }
            else {
                // $this->conn->closeDbConnect();
                return false;
            }
        }
        catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
    // data access for removing a group member
    public function removeGroupMember($userID, $groupID) {
        // connect to the relationship database
        $this->dbObj = new DBConnect("jobpostingsite");
        $this->connection = $this->dbObj->getDbConnect();
        
        try {
            // define the query to submit to the database
            $this->dbQuery = "DELETE FROM groupmembers
							WHERE groupid = " . $groupID .
							" AND userid = " . $userID;
            
            // if the query works
            if (mysqli_query($this->connection, $this->dbQuery)) {
                // $this->conn->closeDbConnect();
                return true;
            }
            else {
                // $this->conn->closeDbConnect();
                return false;
            }
        }
        catch (Exception $e) {
            echo $e->getMessage();
        }
    }
    
    
}


