<?php
namespace App\services\data;

use Illuminate\Support\Facades\DB;
use App\JobPostings;

class JobPostingsData
{
    /**
     * Data access for grabbing all users
     * @return \Illuminate\Support\Collection
     */
    public function getAllJobPostings()
    {
        return DB::table('jobpostings')->select('*')->get(); 
    }
    
    /**
     * Data access tpo add a job
     * @param JobPostings $job
     */
    public function addJob(JobPostings $job)
    {
        DB::table('jobpostings')->insert([
            'title' => $job->getTitle(), 
                'location' => $job->getLocation(), 
                'salary' => $job->getSalary(),
                'description' => $job->getDescription(),
                'type' => $job->getType(),
                 'postedOn' => $job->getType(),
                  'qualifications' => $job->getQualifications()]);
    }
    
    /**
     * Data access too update a job
     * @param JobPostings $job
     */
    public function updateJob(JobPostings $job)
    {
        DB::table('jobpostings')
        ->where('id', $job->getJobID())
        ->update(
            ['title' => $job->getTitle(),
            'location' => $job->getLocation(),
            'salary' => $job->getSalary(),
            'description' => $job->getDescription(),
            'type' => $job->getType(),
            'postedOn' => $job->getType(),
            'qualifications' => $job->getQualifications()      
        ]);
    }
    
    /**
     * Data access to delete a job
     * @param JobPostings $job
     */
   public function deleteJob(JobPostings $job)
   {
       DB::table('jobpostings')->where('id', $job->getJobID())->delete();
   }
   
   public function getJob(int $jobID)
   {
       $job = DB::table('jobpostings')->select('*')
                   ->where('id', $jobID)->get();
       
       return $job;
   }
   
   
    
    
}


