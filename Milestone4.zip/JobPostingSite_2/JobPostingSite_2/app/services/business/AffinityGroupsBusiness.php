<?php
namespace App\services\business;

/*
 * Ana Sanchez
 * Mann Jaiswal
 * Kacey Morris
 * Feb 28, 2021
 * CST 256
 * Job Posting Site - Milestone 4
 * This is our own work as influenced by class time and examples.
 */

use App\services\data\AffinityGroupsData;
use App\AffinityGroup;

class AffinityGroupsBusiness
{
    private $groupsData;
    
    /**
     * Business Layer - Grabs all Groups
     * @return \Illuminate\Support\Collection
     */
    public function getAllGroups()
    {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->getAllGroups();
    }
    
    /**
     * Business Layer - Adds a group to the database
     * @return \Illuminate\Support\Collection
     */
    public function addGroup(AffinityGroup $group)
    {
    	$this->groupsData = new AffinityGroupsData();
    	$this->groupsData->addGroup($group);
    }
    
    /**
     * Business Layer - updates a group in the database
     * @return \Illuminate\Support\Collection
     */
    public function updateGroup(AffinityGroup $group)
    {
    	$this->groupsData = new AffinityGroupsData();
    	$this->groupsData->updateGroup($group);
    }
    
    /**
     * Business Layer - deletes a group from the database
     * @return \Illuminate\Support\Collection
     */
    public function deleteGroup(int $groupID)
    {
    	$this->groupsData = new AffinityGroupsData();
    	$this->groupsData->deleteGroup($groupID);
    }
    
    /**
     * Business Layer - gets a group by the id
     * @return \Illuminate\Support\Collection
     */
    public function getGroup(int $groupID)
    {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->getGroup($groupID);
    }
    
    /**
     * Business Layer - gets all members for a single group
     * @return \Illuminate\Support\Collection
     */
    public function getMembers(int $groupID) {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->getMembers($groupID);
    }
    
    /**
     * Business Layer - joins a user to a group
     * @return \Illuminate\Support\Collection
     */
    public function joinGroup(int $userID, int $groupID) {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->joinGroup($userID, $groupID);
    }
    
    /**
     * Business Layer - removes a member from the group
     * @return \Illuminate\Support\Collection
     */
    public function removeGroupMember(int $userID, int $groupID) {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->removeGroupMember($userID, $groupID);
    }
}


