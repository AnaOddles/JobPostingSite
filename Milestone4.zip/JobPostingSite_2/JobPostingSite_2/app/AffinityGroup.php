<?php

namespace App;

/*
 * Ana Sanchez
 * Mann Jaiswal
 * Kacey Morris
 * Feb 28, 2021
 * CST 256
 * Job Posting Site - Milestone 4
 * This is our own work as influenced by class time and examples. 
 */

use Illuminate\Database\Eloquent\Model;

class AffinityGroup extends Model
{
    // properties
    // the ID for the group
    private $groupID;
    // the title of the group
    private $groupTitle;
    // the description of the group
    private $groupDescription;
    
    // constructor without ID
    public function __construct($groupTitle, $groupDescription)
    {
        $this->groupTitle = $groupTitle;
        $this->groupDescription = $groupDescription;
    }
    
    // getters and setters
    /**
     * @return mixed
     */
    public function getGroupID()
    {
        return $this->groupID;
    }
    
    /**
     * @param mixed $jobID
     */
    public function setGroupID($groupID)
    {
        $this->groupID = $groupID;
    }
    
    /**
     * @return array
     */
    public function getGroupTitle()
    {
        return $this->groupTitle;
    }
    
    /**
     * @return mixed
     */
    public function getGroupDescription()
    {
        return $this->groupDescription;
    }
    /**
     * @param array $guarded
     */
    public function setGroupTitle($groupTitle)
    {
        $this->groupTitle = $groupTitle;
    }
    
    /**
     * @param mixed $title
     */
    public function setGroupDescription($groupDescription)
    {
        $this->groupDescription = $groupDescription;
    }
}
