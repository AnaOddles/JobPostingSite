<?php
namespace App\Http\Controllers;

/*
 * Ana Sanchez
 * Mann Jaiswal
 * Kacey Morris
 * Feb 28, 2021
 * CST 256
 * Job Posting Site - Milestone 4
 * This is our own work as influenced by class time and examples.
 */

use Illuminate\Http\Request;
use App\AffinityGroup;
use App\services\business\AffinityGroupsBusiness;

class AffinityGroupsController
{
    //Controller method to view the create post view
    public function create()
    {
        return view('affinitygroup/create');
    }
    
    /**
     * Method for creating a job posting into the database
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function store()
    {
        $group = new AffinityGroup(request()->get('title'), request()->get('description'));
        
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $groupsBusiness->addGroup($group);
        
        return redirect()->route('affinitygroups.show');
    }
    
    /**
     * Method to view all groups
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function show()
    {
    	$groupsBusiness = new AffinityGroupsBusiness();
        
    	$groups = $groupsBusiness->getAllGroups();
        
        return view('affinitygroup.index')->with('groups', $groups);
    } 
    
    // show a single group
    public function showone($groupID) {
    	// business service
    	$groupsBusiness = new AffinityGroupsBusiness();
    	
    	// get the group info
    	$group = $groupsBusiness->getGroup($groupID);
    	
    	// get the members of that group
    	$members = $groupsBusiness->getMembers($groupID);
    	
    	// return the view one with info
    	return view('affinitygroup/showone')->with('group', $group)->with('members', $members);
    }
    
    // join group with the user id and group id
    public function joinGroup() {
    	// get the information from form
    	$userID = request()->get('userid');
    	$groupID = request()->get('groupid');
    	$groupsBusiness = new AffinityGroupsBusiness();
    	// call bs methods
    	$groupsBusiness->joinGroup($userID, $groupID);
    	// redirect back to groups page
    	return redirect()->route('affinitygroups.show');
    }
    
    //controller method to delete group member
    public function removeGroupMember()
    {
    	$groupsBusiness = new AffinityGroupsBusiness();
    	// get ids for group and user
    	$groupID = request()->get('groupid');
    	$userID = request()->get('userid');
    	
    	// remove that group member
    	$groupsBusiness->removeGroupMember($userID, $groupID);
    	
    	// get the updated groups
    	$groups = $groupsBusiness->getAllGroups();
    	
    	// return the groups view
    	return view('affinitygroup/index')->with('groups', $groups);
    	
    }
}

