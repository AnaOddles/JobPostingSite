<?php

namespace App\Http\Controllers;

/*
 * Ana Sanchez
 * Mann Jaiswal
 * Kacey Morris
 * Feb 28, 2021
 * CST 256
 * Job Posting Site - Milestone 4
 * This is our own work as influenced by class time and examples.
 */

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use App\JobPostings;
use App\User;
use App\services\business\AdminBusiness;
use App\services\business\JobPostingsBusiness;
use App\services\business\AffinityGroupsBusiness;
use App\AffinityGroup;


class AdminController extends Controller
{
    //Constructor with calling the admin
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    //controller method for the admin view
    public function admin()
    {
        $adminData = new AdminBusiness();
        
        $users = $adminData->getAllUsers();
        
        //returns view with all the users
        return view('admin/admin')->with('users', $users);
    }
    
    //controller method for the update user
    public function updateUser(User $user, string $suspended, string $type)
    {
        $adminData = new AdminBusiness();
        
        $adminData->updateUser($user, $type, $suspended);
        
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users);
    }
    
    
    //controller method to updateRole 
    public function updateRole(int $userID, Request $request)
    {
        $adminData = new AdminBusiness();
        
        $fields = Input::get("radio");
        if($fields == "admin")
        {
            $role = 'admin';
        }
        else
        {
            $role = 'default';
        }
        
        $adminData->updateRole($userID, $role);
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users); 
    }
    
    //controller method to susoend a user 
    public function suspendUser(int $userID)
    {
        $adminData = new AdminBusiness();
        
        $adminData->suspendUser($userID);
        
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users);
        
    }
    
    //controller method to delete user 
    public function deleteUser(int $userID)
    {
        $adminData = new AdminBusiness();
        
        $adminData->deleteUser($userID);
        
        $users = $adminData->getAllUsers();
        return view('admin/admin')->with('users', $users);
        
    }
    
    // shows all jobs
    public function showAdmin()
    {
        $jobData = new JobPostingsBusiness();
        
        $jobs = $jobData->getAllJobs();
        
        // return admin view with all jobs
        return view('admin/adminjobs')->with('jobs', $jobs);
    }
    
    //controller method for the update job
    public function updateJob()
    {
        $jobData = new JobPostingsBusiness();
        
        // get new info from fields
        $job = new JobPostings(request()->get('title'), request()->get('location'),
            request()->get('salary'), request()->get('description'), request()->get('type'),
            request()->get('postedOn'), request()->get('qualifications'));
        
        // get the id
        $job->setJobID(request()->get('id'));
        
        // update the job
        $jobData->updateJob($job);
        
        // get an updated job list
        $jobs = $jobData->getAllJobs();
        
        // return the view with the new jobs list
        return view('admin/adminjobs')->with('jobs', $jobs);
    }
    
    // admin edit job
    public function editJob(){
        
        $jobID = request()->get('id');
        $jobData = new JobPostingsBusiness();
        // get the job from database
        $jobs = $jobData->getJob($jobID);
        //$job->toArray();
        
        // return the view with existing information
        return view('admin/editJob')->with('jobs', $jobs);
    }
    
    //controller method to delete job
    public function deleteJob()
    {
        $jobData = new JobPostingsBusiness();
        
        // create job
        $job = new JobPostings(request()->input('title'), request()->get('location'),
            request()->get('salary'), request()->get('description'), request()->get('type'),
            request()->get('postedOn'), request()->get('qualifications'));
        
        // get id from form
        $job->setJobID(request()->get('id'));
        
        // delete the job
        $jobData->deleteJob($job);
        
        // get updated list
        $jobs = $jobData->getAllJobs();
        
        // return view with job lsit
        return view('admin/adminjobs')->with('jobs', $jobs);
        
    }
    
    // show all groups admin view
    public function showGroupsAdmin()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $groups = $groupsBusiness->getAllGroups();
        
        // admin view with all groups
        return view('admin/groups')->with('groups', $groups);
    }
    
    // function to edit group
    public function editGroup()
    {
    	// get the group id
        $groupID = request()->get('groupid');
        $groupsBusiness = new AffinityGroupsBusiness();
        // access information 
        $group = $groupsBusiness->getGroup($groupID);
        $members = $groupsBusiness->getMembers($groupID);
        
        // return the edit form with information about group
        return view('admin/editGroup')->with('group', $group)->with('members', $members);
    }
    
    //controller method to delete group
    public function deleteGroup()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        // get the group id
        $groupID = request()->get('groupid');
        // delete from database
        $groupsBusiness->deleteGroup($groupID);
        // get updated group list
        $groups = $groupsBusiness->getAllGroups();
        // return the groups with new list
        return view('admin/groups')->with('groups', $groups);
        
    }
    
    //controller method for the update job
    public function updateGroup()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        // get updated information 
        $group = new AffinityGroup(request()->get('grouptitle'), request()->get('groupdescription'));
        // set the id
        $group->setGroupID(request()->get('groupid'));
        // update database
        $groupsBusiness->updateGroup($group);
        // get update group info
        $groups = $groupsBusiness->getAllGroups();
        $members = $groupsBusiness->getMembers(request()->get('groupid'));
        // return admin groups with the new info
        return view('admin/groups')->with('groups', $groups)->with('members', $members);
    }
    
    //controller method to delete group
    public function removeGroupMember()
    {
        $groupsBusiness = new AffinityGroupsBusiness();
        // get id for group and user
        $groupID = request()->get('groupid');
        $userID = request()->get('userid');
        // remove that user from the group
        $groupsBusiness->removeGroupMember($userID, $groupID);
        // get updated list
        $groups = $groupsBusiness->getAllGroups();
        // return view with updated list
        return view('admin/groups')->with('groups', $groups);
        
    }
}
