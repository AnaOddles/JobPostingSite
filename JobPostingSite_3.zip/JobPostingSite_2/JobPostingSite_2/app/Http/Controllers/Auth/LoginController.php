<?php
/*
 * Name: Mann Jaiswal, Kacey Morris, Ana Sanchez
 * Php 3 Laravel
 * All work is our as influenced  by in class lecture
 */
namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    //Uses all business logic of AuthenticatesUsers obj
    //including validations
    use AuthenticatesUsers;

    //redirects the user to their profile on login 
    protected function redirectTo(){
       return "/profiles/" . auth()->user()->id;
    }

    
    
    //redirects the user to logout once loged out
    protected function logout(Request $request) {
        Auth::logout();
        return redirect('/login');
    }
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
}
