<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\AffinityGroup;
use App\services\business\AffinityGroupsBusiness;

class AffinityGroupsController
{
    //Controller method to view the create post view
    public function create()
    {
        return view('affinitygroup/create');
    }
    
    /**
     * Method for creating a job posting into the database
     * @return \Illuminate\Routing\Redirector|\Illuminate\Http\RedirectResponse
     */
    public function store()
    {
        $group = new AffinityGroup(request()->get('title'), request()->get('description'));
        
        $groupsBusiness = new AffinityGroupsBusiness();
        
        $groupsBusiness->addGroup($group);
        
        return redirect()->route('affinitygroups.show');
    }
    
    /**
     * Method to view all groups
     * @return \Illuminate\View\View|\Illuminate\Contracts\View\Factory
     */
    public function show()
    {
    	$groupsBusiness = new AffinityGroupsBusiness();
        
    	$groups = $groupsBusiness->getAllGroups();
        
        return view('affinitygroup/index')->with('groups', $groups);
    } 
    
    public function showone($groupID) {
    	$groupsBusiness = new AffinityGroupsBusiness();
    	
    	$group = $groupsBusiness->getGroup($groupID);
    	
    	$members = $groupsBusiness->getMembers($groupID);
    	
    	return view('affinitygroup/showone')->with('group', $group)->with('members', $members);
    }
    
    public function joinGroup() {
    	$userID = request()->get('userid');
    	$groupID = request()->get('groupid');
    	$groupsBusiness = new AffinityGroupsBusiness();
    	$groupsBusiness->joinGroup($userID, $groupID);
    	return redirect()->route('affinitygroups.show');
    }
    
    //controller method to delete group
    public function removeGroupMember()
    {
    	$groupsBusiness = new AffinityGroupsBusiness();
    	
    	$groupID = request()->get('groupid');
    	$userID = request()->get('userid');
    	
    	$groupsBusiness->removeGroupMember($userID, $groupID);
    	
    	$groups = $groupsBusiness->getAllGroups();
    	
    	return view('affinitygroup/index')->with('groups', $groups);
    	
    }
}

