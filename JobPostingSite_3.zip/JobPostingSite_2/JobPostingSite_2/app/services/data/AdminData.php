<?php
namespace App\services\data;

use App\User;
use Illuminate\Support\Facades\DB;

class AdminData
{
    /**
     * Data access for grabbing all users
     * @return \Illuminate\Support\Collection
     */
    public function getAllUsers()
    {
        return DB::table('users')->select('*')->get();
          
    }
    
    /**
     * Data access for updating user
     * @param User $user
     * @param string $type
     * @param bool $suspended
     */
    public function updateUser(User $user, string $type, bool $suspended)
    {
        DB::table('users')
        ->where('id', $user->id)
        ->update(['type' => $type, 
                  'suspended' =>$suspended,
            
        ]);
    }
    
    /**
     * Data access for deleting a user
     * @param User $user
     */
    public function deleteUser(int $userID)
    {
        DB::table('users')->where('id', $userID)->delete();
    }
    
    /**
     * Data Access  for updating user role
     * @param int $userID
     * @param string $type
     */
    public function updateRole(int $userID, string $type)
    {
        DB::table('users')
        ->where('id', $userID)
        ->update(['type' => $type,   
        ]);
    }
    
    /**
     * Data Access tp suspend a user
     * @param int $userID
     */
    public function suspend(int $userID)
    {
        DB::table('users')
        ->where('id', $userID)
        ->update(['suspended' => true,
        ]);
    }    
    
}

