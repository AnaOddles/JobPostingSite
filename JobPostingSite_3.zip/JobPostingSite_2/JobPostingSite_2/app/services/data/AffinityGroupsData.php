<?php
namespace App\services\data;

use Illuminate\Support\Facades\DB;
use App\JobPostings;
use App\AffinityGroup;
use Carbon\Exceptions\Exception;
use App\Services\Data\Utility\DBConnect;

class AffinityGroupsData
{
	// database connection
	private $dbObj;
	private $connection;
	private $dbQuery;
    /**
     * Data access for grabbing all groups
     * @return \Illuminate\Support\Collection
     */
    public function getAllGroups()
    {
        return DB::table('affinitygroup')->select('*')->get(); 
    }
    
    /**
     * Data access tpo add a job
     * @param JobPostings $job
     */
    public function addGroup(AffinityGroup $group)
    {
        DB::table('affinitygroup')->insert([
            'grouptitle' => $group->getGroupTitle(), 
             'groupdescription' => $group->getGroupDescription(),
		]);
    }
    
    /**
     * Data access too update a job
     * @param JobPostings $job
     */
    public function updateGroup(AffinityGroup $group)
    {
        DB::table('affinitygroup')
        ->where('groupid', $group->getGroupID())
        ->update(
            ['grouptitle' => $group->getGroupTitle(),
            'groupdescription' => $group->getGroupDescription()    
        ]);
    }
    
    /**
     * Data access to delete a job
     * @param JobPostings $job
     */
    public function deleteGroup(int $groupID)
   {
       DB::table('affinitygroup')->where('groupid', $groupID)->delete();
   }
   
   public function getGroup(int $groupID)
   {
       $group = DB::table('affinitygroup')->select('*')
                   ->where('groupid', $groupID)->get();
       
       return $group;
   }
   
   // get all members of the group with this ID
   public function getMembers($groupID) {
   		// connect to the relationship database
   		$this->dbObj = new DBConnect("jobpostingsite");
   		$this->connection = $this->dbObj->getDbConnect();
   		
   		try {
   			// define the query to submit to the database
   			$this->dbQuery = "SELECT userid, name
							FROM groupmembers gm
							JOIN users u
							ON u.id = gm.userid
							WHERE groupid = " . $groupID;
   			   			
   			$result = mysqli_query($this->connection, $this->dbQuery);
   			
   			// add members to array
   			$members = Array();
   			
   			while ($member = $result->fetch_assoc()) {
   				array_push($members, $member);
   			}
   			
   			return $members;
   		}
   		catch (Exception $e) {
   			echo $e->getMessage();
   		}
   }
   
   public function joinGroup($userID, $groupID) {
	   	// connect to the relationship database
	   	$this->dbObj = new DBConnect("jobpostingsite");
	   	$this->connection = $this->dbObj->getDbConnect();
	   	
	   	try {
	   		// define the query to submit to the database
	   		$this->dbQuery = "INSERT INTO groupmembers
								VALUES (
									" . $groupID . ",
									" . $userID . "
								)";
	   		
	   		// if the query works
	   		if (mysqli_query($this->connection, $this->dbQuery)) {
	   			// $this->conn->closeDbConnect();
	   			return true;
	   		}
	   		else {
	   			// $this->conn->closeDbConnect();
	   			return false;
	   		}
	   	}
	   	catch (Exception $e) {
	   		echo $e->getMessage();
	   	}
   }
   
   public function removeGroupMember($userID, $groupID) {
   	// connect to the relationship database
   	$this->dbObj = new DBConnect("jobpostingsite");
   	$this->connection = $this->dbObj->getDbConnect();
   	
   	try {
   		// define the query to submit to the database
   		$this->dbQuery = "DELETE FROM groupmembers
							WHERE groupid = " . $groupID . 
   							" AND userid = " . $userID;
   		
   		// if the query works
   		if (mysqli_query($this->connection, $this->dbQuery)) {
   			// $this->conn->closeDbConnect();
   			return true;
   		}
   		else {
   			// $this->conn->closeDbConnect();
   			return false;
   		}
   	}
   	catch (Exception $e) {
   		echo $e->getMessage();
   	}
   }
    
    
}


