<?php
namespace App\services\business;
use App\services\data\AffinityGroupsData;
use App\AffinityGroup;

class AffinityGroupsBusiness
{
    private $groupsData;
    
    /**
     * Business Layer - Grabs all Groups
     * @return \Illuminate\Support\Collection
     */
    public function getAllGroups()
    {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->getAllGroups();
    }
    
    public function addGroup(AffinityGroup $group)
    {
    	$this->groupsData = new AffinityGroupsData();
    	$this->groupsData->addGroup($group);
    }
    
    public function updateGroup(AffinityGroup $group)
    {
    	$this->groupsData = new AffinityGroupsData();
    	$this->groupsData->updateGroup($group);
    }
    
    public function deleteGroup(AffinityGroup $group)
    {
    	$this->groupsData = new AffinityGroupsData();
    	$this->groupsData->deleteGroup($group);
    }
    
    public function getGroup(int $groupID)
    {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->getGroup($groupID);
    }
    
    public function getMembers(int $groupID) {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->getMembers($groupID);
    }
    
    public function joinGroup(int $userID, int $groupID) {
    	$this->groupsData = new AffinityGroupsData();
    	return $this->groupsData->joinGroup($userID, $groupID);
    }
}


