<?php
namespace App\services\business;
use App\services\data\PortfolioData;
use App\User;

class PortfolioBusiness
{
    private $portfolioData; 
    
    public function updatePortfolio(User $user){
        $this->portfolioData = new PortfolioData();
        return $this->portfolioData->update($user);
    }
}

