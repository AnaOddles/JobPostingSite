@extends('layouts.app') @section('content')
<div class="container">
	<form action="{{route('storeGroupAdmin')}}" enctype="multipart/form-data" method="post">
		@csrf
		<div class="row">
			<div class="col-8 offset-2">
				<div class="row">
					<h1>Add New Group</h1>
				</div>
				<div class="form-group row">
					<label for="title" class="col-md-4 col-form-label">Title:</label>


					<input id="title" type="text"
						class="form-control"
						name="title"> 
				</div>
				
				<div class="form-group row">
					<label for="description" class="col-md-4 col-form-label">Description:</label>


					<input id="description" type="text"
						class="form-control"
						name="description"> 
				</div>

				<div class="row pt-4">
					<button class="btn btn-primary">Add New Group</button>
				</div>

			</div>
		</div>
	</form>
</div>
@endsection
