@extends('layouts.app') @section('content')
<div class="container">
	<div class="col-8 offset-2">
		<div class="row">
			<h1><?php echo $group[0]->grouptitle?></h1>
		</div>
		<div class="form-group row">
			<label for="title" class="col-md-4 col-form-label">Title:</label>
			<input id="title" type="text"
				class="form-control"
				name="title" value="<?php echo $group[0]->grouptitle?>" readonly> 
		</div>
		
		<div class="form-group row">
			<label for="description" class="col-md-4 col-form-label">Description:</label>


			<input id="description" type="text"
				class="form-control"
				name="description" value="<?php echo $group[0]->groupdescription?>" readonly> 
		</div>
			
		<div class="list-group">
		<?php foreach ($members as $member) { ?>
			<a href="{{ route('portfolio.show', ['user' => $member['userid'] ]) }}" class="list-group-item list-group-item-action"><?php echo $member['userid'] . " : " . $member['name'] ?></a>
		<?php } ?>
		</div>

	</div>
</div>
@endsection
