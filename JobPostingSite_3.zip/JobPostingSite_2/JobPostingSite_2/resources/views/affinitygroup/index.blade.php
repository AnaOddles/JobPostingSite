@extends('layouts.app') 

@section('content')
<?php session_start();?>

<div class="container">
	<h1>Affinity Groups</h1>

	<!-- start of the table -->

	<div class="container" padding="50px">

		<table class="table table-hover">

			<thead>

				<tr>

					<!-- table header data -->
					<th scope="col">ID</th>

					<th scope="col">Title</th>
					
					<th scope="col">Description</th>
					
					<th scope="col">Join</th>

				</tr>

			</thead>

			<tbody>
				<!-- populate the table with the appropriate group information -->
				<?php
				foreach ($groups as $group) {
    				echo "<tr>";

    				echo "<th scope='row'>" . $group->groupid . "</th>";
    				
    				// form to show members in a group
    				echo "<td>";
    				?>
    	
 					<form action="{{route('affinitygroups.showone', ['group' => $group->groupid]) }}" method='post'>
 						{{ csrf_field() }}
     				<?php
    				echo "<input type='hidden' name='id' value='" . $group->groupid . "'>";
    				echo "<input class='btn btn-link' type='submit' name='submit' value='". $group->grouptitle . "'>";
    				echo "</form>";
    				
    				echo "</td>";
    				
    				echo "<td>" . $group->groupdescription . "</td>";
    				
    				// form to join a group
    				echo "<td>";
    				// , ['userid' => $groupid, ['groupid' => $group->groupid]
    				?>
    	
 					<form action="{{route('joingroup') }}" method='post'>
 						{{ csrf_field() }}
     				<?php
    				echo "<input type='hidden' name='userid' value='" . $_SESSION['userid'] . "'>";
    				echo "<input type='hidden' name='groupid' value='" . $group->groupid . "'>";
    				// if the user is already in the group, do not show button
    				echo "<input class='btn btn-link' type='submit' name='submit' value='Join Group'>";
    				echo "</form>";
    				
    				echo "</td>";
    
    				echo "</tr>";
				}
				?>

			
			</tbody>

		</table>

	</div>

</div>
@endsection
